package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class JoiningDemo1
{
	public static void main(String[] args) {
		
	
	SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	Session session=factory.openSession();
	Transaction tx=session.beginTransaction();
//	
//		Book book1=new Book();
//		book1.setBookName("c");	
//    	book1.setBookPrice(900.76);
//    	book1.setBookPages(700);
//    	
//    	
//    	Author author=new Author();
//    	author.setaId(201);
//    	author.setName("balaguruswamy");
//    	
//    	book1.setAuthor(author);  //saving author as foreign key in book
//    	
//    	session.save(book1);
//    	session.save(author);
//    	tx.commit();
    	
    	//retrieve data
    	
    	Book b=session.get(Book.class,1);
    	System.out.println("Book Name: "+b.getBookName()+"\t Author Name: "+b.getAuthor().getName());
    	tx.commit();
    	
    	
    	
    	session.close();
    	factory.close();
	
	}
}
