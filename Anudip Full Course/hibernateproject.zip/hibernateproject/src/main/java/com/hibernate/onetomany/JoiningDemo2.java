package com.hibernate.onetomany;

import java.util.ArrayList;
import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class JoiningDemo2
{
	public static void main(String[] args) {
		
	
	SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	Session session=factory.openSession();
	Transaction tx=session.beginTransaction();
//	
//		Author author1=new Author();
//		author1.setaId(101);
//		author1.setName("balaguruswamy");
//	
//	
//	
//		Book book1=new Book();
//		book1.setBookName("c");	
//    	book1.setBookPrice(900.76);
//    	book1.setBookPages(700);
//    	book1.setAuthor(author1);  //saving author as foreign key in book
//    	
//    	Book book2=new Book();
//		book2.setBookName("data structure with c");	
//    	book2.setBookPrice(600.76);
//    	book2.setBookPages(500);
//    	book2.setAuthor(author1);
//    	
//    	//arraylist to store many books
//    	List<Book> books=new ArrayList<Book>();
//    	books.add(book1);
//    	books.add(book2);
//    	
////    	//adding all books in list created in author class
//   	author1.setBooks(books);
//    	
//    	
//   	session.save(author1); //when we save author ,books also save with author due to  cascading
//   	tx.commit();
	
	
	
	//fetch/retrive data
	
//	Author author=session.get(Author.class, 101);
//	System.out.println("Author Name: "+author.getName());
//	
//	System.out.println("Book Details");
//	for(Book book:author.getBooks())
//	{
//		//System.out.println("Book Name: "+book.getBookName()+"Book Price: "+book.getBookPrice());
//		
//	}
    	
	
	//Using HQL
	
	//fetching data of Author
	
//	String query1="from Author";
//	Query q1 =session.createQuery(query1);
//	List<Author> alist=q1.getResultList();
//	
//	for(Author au:alist)
//	{
//		System.out.println("Author Name: "+au.getName());
//	}
	
	
	//fetching book details using HQL
	//String query="from Book where bookId=1 ";
	
//	String query="from Book where bookName=:c";
//   Query q=	session.createQuery(query);
//  
//   q.setParameter("c", "data structure with c");
//   
//   List<Book> list= q.getResultList();
//   for(Book b:list)
//   {
//	   System.out.println("Book Name: "+b.getBookName()+"\t Book Price: "+b.getBookPages()+"\t Book Price: "+b.getBookPrice());
//	  System.out.println(b);
//   }

	
	//delete Querry
//	Query q=session.createQuery("delete from Book b where b.bookId=:b");
//	q.setParameter("b", 1);
//	
//	int row =q.executeUpdate();
//	System.out.println(row+"record delete succesfully...");
//	tx.commit();
//	
	
//  update query
	
//	Query q= session.createQuery("update Book set bookName=:bn, bookPrice=:p where bookId=:i");
//	q.setParameter("bn", "ds with java ");
//	q.setParameter("p",900.76 );
//	q.setParameter("i", 1);
//	
//	int r=q.executeUpdate();
//	System.out.println(r+ "record updated sucessfully");
//	tx.commit();
//    	
    	
	
	Query q=session.getNamedQuery("book.byname");
	q.setString(1, "data structure with c");
	List<Book> l=q.list();
	for(Book b:l)
	{
		System.out.println(b);
	}
//			
    	
    	session.close();
    	factory.close();
	
	}
}
