package com.hibernate.onetomany;



import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Author 
{
	@Id
	private int aId;
	private String name;
	
	//one author can write many books
	@OneToMany(mappedBy = "author",cascade = CascadeType.ALL)
	List<Book> books; 
	
	public List<Book> getBooks() {
		return books;
	}
	public void setBooks(List<Book> books) {
		this.books = books;
	}
	public int getaId() {
		return aId;
	}
	public void setaId(int aId) {
		this.aId = aId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public Author(int aId, String name, List<Book> books) {
		super();
		this.aId = aId;
		this.name = name;
		this.books = books;
	}
	public Author() {
		super();
		
	}
	@Override
	public String toString() {
		return "Author [aId=" + aId + ", name=" + name + "]";
	}
	
	
	
	
}

