package com.hibernate.onetomany;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name="book_info")
@NamedQuery(name = "book.byname",query = "from Book where bookName=?1")
public class Book 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int bookId;
	
	
	@Column(name="book_name",length = 50)
	String bookName;
	
	@Column(name="book_price",length= 10)
	double bookPrice;
	
	@Column(name="book_pages",length =10)
	int bookPages;

	@ManyToOne  //many books can written by one author
	@JoinColumn(name ="aid")
	private Author author;
	
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	public int getBookPages() {
		return bookPages;
	}
	public void setBookPages(int bookPages) {
		this.bookPages = bookPages;
	}
	public Book(int bookId, String bookName, double bookPrice, int bookPages, Author author) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookPrice = bookPrice;
		this.bookPages = bookPages;
		this.author = author;
	}
	public Book() {
		super();
		
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", bookPrice=" + bookPrice + ", bookPages="
				+ bookPages + "]";
	}
	
	
	
	
	
	
	
	
}
