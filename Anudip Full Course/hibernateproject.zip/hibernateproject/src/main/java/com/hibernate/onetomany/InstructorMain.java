package com.hibernate.onetomany;



public class InstructorMain 
{
	public static void main(String[] args) 
	{
		
	}

}
