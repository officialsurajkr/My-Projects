package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//       Configuration cfg=new Configuration();
//       cfg.configure("hibernate.cfg.xml");
//       SessionFactory factory=cfg.buildSessionFactory();
       
       //or we can write this in single line also
       
    	SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    	Session session=factory.openSession();
    	Transaction tx=session.beginTransaction();
    	
//    	
//    	Book book3=new Book();
//    	
//    	book3.setBookName ("clean code");
//    	book3.setBookPrice(650.76);
//    	book3.setBookPages(900);
//    	
//    	session.save(book3);
//    	tx.commit();
    	
    	
    	//Retrieve/fetching data from data base
    	
    	Book book=session.get(Book.class , 1);
    	System.out.println(book);
    	
    	Book book1=session.load(Book.class , 4);
    	System.out.println(book1);
    	
    	session.close();
    	
    	Session session2=factory.openSession();
   
    	Book book4=session2.get(Book.class , 1);
    	System.out.println(book4);
    	
    	Book book3=session2.load(Book.class , 1);
    	System.out.println(book3);
    	
    	session.close();
    	factory.close();
       
    }
}
