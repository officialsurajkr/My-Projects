package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmbaddableDemo 
{
	public static void main(String[] args)
	{
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    	Session session=factory.openSession();
    	Transaction tx=session.beginTransaction();
    	
    	Certificate certi1=new Certificate("Java full stack"," 4 months");
    	Certificate certi2=new Certificate("dotnet"," 3 months");
    	
    	StudentEx student1=new StudentEx();
    	student1.setName("Suraj");
    	student1.setCity("Dhanbad");
    	student1.setCertificate(certi1);
    	
    	StudentEx student2=new StudentEx();
    	student2.setName("nilanjan");
    	student2.setCity("kolkata");
    	student2.setCertificate(certi2);
    	
    	session.save(student1);
    	session.save(student2);
    	tx.commit();
    	
    	//Retrieve data
    	StudentEx student=session.get(StudentEx.class, 1);
    	System.out.println(student);
    	
    	
    	
    	
    	
    	//delete data from table
//    	session.delete(student2);
//    	System.out.println("record got deleted");
//    	tx.commit();
    	
    	//session.clear();  remove all instance from session cache
    	//session.evict(student2);  //remove student2 instance from session cache
    	
//    	StudentEx student3=session.get(StudentEx.class, 2);
//    	System.out.println(student2);
    	
    	
    //	session.close();
    	//session.save(student2);
    	
    	//cache
    	StudentEx s= session.get(StudentEx.class, 1);
    	System.out.println(s);
    	session.close();
    	
    	Session session1 =factory.openSession();
    	StudentEx s1=session1.get(StudentEx.class, 1);
    	System.out.println(s1);
    	
    	
    	factory.close();
    	
    	
    	
    	
	}
}
