package exceptionhandling;

//unchecked exception
public class NumberNotDevideException extends RuntimeException
{
	
		public NumberNotDevideException (String message)
		{
			super(message);
		}

	}



