
package oops;

class Bank     //parent class
{
	public void loneIntrest()
	{
		System.out.println("9% Intrest Rate");
	}
}
class Sbii extends Bank   //child class
{
	public void pensionScheam()
	{
		System.out.println("minimum 5 year scheam you need to take");
	}
	
}

class Axiss extends Bank    //another child class
{
	public void fixedDeposit()
	{
		System.out.println("tenor is 5 year");
	}
}

public class HierarchalInheritance 
{
	public static void main(String[] args) 
	{
			Sbii sbi=new Sbii();
			sbi.loneIntrest();
			sbi.pensionScheam();
			
			
			Axiss axis=new Axiss();
			axis.loneIntrest();
			axis.fixedDeposit();
	}

}
