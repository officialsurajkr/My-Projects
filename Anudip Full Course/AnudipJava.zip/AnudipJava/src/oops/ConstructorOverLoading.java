package oops;

class Employ
{
	int id;
	String name,city,country,state,designation;
	long phno,salary;
	final int aadharno;
	
	//Constructor to initialized id,name,city
	public Employ(int id,String name, String city,int aadharno)
	{
		this.id=id;
		this.name=name;
		this.city=city;
		this.aadharno=aadharno;
		
	}
	
	public Employ(int id,String name, String city, int aadharno ,String country,String state,String designation)
	{
		this(id,name,city,aadharno);  //Constructor Chaining
		this.country=country;
		this.state=state;
		this.designation=designation;
		
		
	}
	
	public Employ(int id,String name, String city,int aadharno,String country,
			String state,String designation,long phno,long salary)
	{
		this(id,name,city,aadharno,country,state,designation);
		this.phno=phno;
		this.salary=salary;
		
		
	}

	@Override
	public String toString() {
		return "Employ [id=" + id + ", name=" + name + ", city=" + city + ", country=" + country + ", state=" + state
				+ ", designation=" + designation + ", phno=" + phno + ", salary=" + salary + ", aadharno=" + aadharno
				+ "]";
	}

	

	





}
public class ConstructorOverLoading
{
	public static void main(String[] args) 
	{
		Employ em1=new Employ(101,"Suraj","Dhanbad",1222938,"India","Jharkhand","it",98754654,22000);
		System.out.println(em1);
	}
	

}
