package basicprograms;

public class LoopDemo
{
	public static void main(String[] args) 
	{
		//Counter Variable for loop
		int i;
		for(i=0 ; i<5 ; i++)
		{
			System.out.println("Hello World");
		}
		
	}

}
