
//W.A.P to print multiplication table of given number

package basicprograms;
import java.util.Scanner;

public class MultiplicationTable
{
	public static void main(String[] args)
	{
		int num,i;  //Counter Variable for loop
		
		Scanner sc=new Scanner(System.in);  //Using Scanner Class to take input from user
		
		System.out.println("Give a number ");
		 num=sc.nextInt();
		
		System.out.println("The Multiplication Table of "+num+ " is");
		
		for( i=1 ; i<=10 ; i++)
		{
			System.out.println(num +"*" +i+ "=" + num*i );
		}
		
		
	}

}
