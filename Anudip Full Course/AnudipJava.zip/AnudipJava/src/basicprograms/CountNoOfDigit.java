package basicprograms;
import java.util.*;

public class CountNoOfDigit 
{
	public static void main(String[] args) 
	{
		int count=0 , number ,temp;  //counter variable for loop
		Scanner sc=new Scanner(System.in);  // creating Scanner Object
		System.out.println("Enter a Number: ");
			number=sc.nextInt();
			temp=number;		
			
			while(number>0)
			{
				count++;
				number=number/10;
			}
	System.out.println("Total no. of  Digits in "+ temp + " is "+ count);
	}

}
