package demo;

import java.util.Scanner;

public class SplitSentence
{
	
	public static void split()
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter a Sentence");
		String str=sc.nextLine();
		
		String strArr[]=str.split(" "); //it will break sentence into words
		
		int length=strArr.length; //5
		
		for(int i=1; i<length ; i++ )  ///i=1, 2
		{
		String word=strArr[i];  //welcome ,to
		int n=i-1;				//0, 1
		
		while(n>=0 && word.length()<strArr[n].length())  //0>=0 && 7<5  false
			{											//1>=0 &&  2<5 true
				strArr[n+1]=strArr[n];  //  it will replace the position of words
				n--;
			}
			strArr[n+1]=word; 
		}
		
		//print the sorting word
		for(int i=0 ; i<strArr.length ; i++)
			{
				System.out.println(strArr[i]);
			}
				
				 
		
	}
	
	
	
	//main method 
	public static void main(String[] args) 
	{
		split();
	}

}
