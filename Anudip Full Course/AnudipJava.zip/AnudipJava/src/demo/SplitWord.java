package demo;

import java.util.Scanner;

public class SplitWord 
{
	public static void display()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Sentence");
		String st=sc.nextLine();
		
		String arr[]=st.split(" "); //it will break sentence into words
		
		for(int i=0; i< arr.length-1; i++ ) //external loop
		{
			for(int j=i+1; j<arr.length;j++) //internal loop
			{
				if(arr[i].length()>arr[j].length())
				{
					String str=arr[i];
					arr[i]=arr[j];
					arr[j]=str;
				}
			}
		}//end of loop
		
		//print the sorted words
		for(int i=0; i<arr.length;i++)
		{
			System.out.println(arr[i]);
			
		}
		
		
	}
	
	public static void main(String[] args)
	{
		display();
		
	}
}
