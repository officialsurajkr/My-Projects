
/*1.write a program to create Book management system.
create class name Book,and perform following actions:
Attributes:bookid,bookName,bookPrice,authorName,
library name(static),availability
method:
createBook() will store book details.(add atleast 5 books).
displayBook()will display book details
displayBookByName(): display specific book details based on bookName
borrowBook(): borrow book if book is available based on bookName,
then make availability status as "not available"*/

package thursdaylab;

import java.util.Scanner;

public class Book2
{
	int bookId;
	String bookName, authorName;
	float bookPrice;
	static String library= "Anudip Library";
	String availanlity;
	
	public void createBook(int bookId, String bookName, String authorName,float bookPrice)
	{
		this.bookId=bookId;
		this.bookName=bookName;
		this.authorName=authorName;
		this.bookPrice=bookPrice;	
	}
		
	
	public void dispalyBookDetails()
	{
		
	System.out.println("Book Id:"+bookId+" Book Name:"+bookName
	+" Author Name:"+authorName+" Book Price:"+bookPrice+" Library Name:"+library);
		System.out.println("=========================");

	}
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
			System.out.println("Enter Book Id:");
			int	bookId=Integer.parseInt(sc.nextLine());
			
			System.out.println("Enter Book Name:");
			String bookName=sc.nextLine();
			
			System.out.println("Enter Author Name:");
			String authorName=sc.nextLine();
			
			System.out.println("Enter Book Price");
		//	float bookPrice=Float.parseFloat(sc.nextLine());
			float bookPrice=sc.nextFloat();
			
			Book2 bobj=new Book2();
				bobj.createBook(bookId, bookName, authorName, bookPrice);
				bobj.dispalyBookDetails();
				
			
		
				
			
		
	}
}
