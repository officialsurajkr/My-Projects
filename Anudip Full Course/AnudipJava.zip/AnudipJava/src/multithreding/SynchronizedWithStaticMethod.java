package multithreding;

class printData1
{
	
	static synchronized void multiplication(int n)
	{
		System.out.println("Outside of synchronized block");
		for(int i=1;i<=5;i++)
		{
			System.out.println(n*i);
			try
			{
				Thread.sleep(400);	
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}//end of for loop
		System.out.println("rest of code which not to synchonized");
	} //end of synchronized method

}

class printAdd
{
	 synchronized void addition(int n)
	{
		System.out.println("Outside of synchronized block");
		for(int i=1;i<=5;i++)
		{
			System.out.println(n+i);
			try
			{
				Thread.sleep(400);	
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}//end of for loop
		System.out.println("rest of code which not to synchonized");
	} //end of synchronized method
	
}


public class SynchronizedWithStaticMethod 
{
	public static void main(String[] args) 
	{
		
		Thread t1=new Thread()
		{
			public void run()
			{
				printData1.multiplication(5);
			}
		};
		
		Thread t2=new Thread()
				{
				public void run()
				{
					printData1.multiplication(10);
				}
				};
				
				printAdd padd=new printAdd();
				
				Thread t3=new Thread()
				{
					public void run()
					{
						//printData1.multiplication(20);
						//printAdd.addition(20);
					padd.addition(100);
						
					}
				};
				
				Thread t4=new Thread()
						{
						public void run()
						{
							//printData1.multiplication(100);
							//printAdd.addition(100);
							padd.addition(1000);
						}
						};
						
						
						
		
	
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		
	}
	}

