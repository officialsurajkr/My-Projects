package lab_18_8_22;

public class StudentIdNotFoundException extends Exception
{
	public StudentIdNotFoundException(String message)
	{
		super(message);
	}
}
