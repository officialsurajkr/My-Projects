package lab_18_8_22;

public class NoCourseFoundException extends Exception
{
	public NoCourseFoundException(String message)
	{
		super(message);
	}
}
