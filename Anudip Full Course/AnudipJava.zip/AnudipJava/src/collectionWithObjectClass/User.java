package collectionWithObjectClass;

public class User implements Comparable<User>
{
	private int id;
	private String name;
	private String address;
	
	// getter and setter 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	//constructor
	public User(int id, String name, String address) 
	{
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}
	//constructor from super class
	public User() {
		super();
		
	}
	//toString
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", address=" + address + "]";
	}
	//for sorting
	@Override
	public int compareTo(User o) {
//		if(id==o.id)
//		return 0;
//		else if(id>o.id)  //for reverse order else if(id<o.id)
//			return 1;
//		else
//			return -1;
		
		return((name.length()>o.name.length())?1 :-1);   //Compare with names
	}
	
	
	
	
	
	
	
	
	
	

}
