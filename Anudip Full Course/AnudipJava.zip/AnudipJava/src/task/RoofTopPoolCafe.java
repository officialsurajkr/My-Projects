package task;

interface Resturant
{
	
	void pooltype();
}

interface RoofTop
{
	void rooftoptype();
}

class RP implements RoofTop
{

	@Override
	public void rooftoptype()
	{
		System.out.println("This is Rooftop Resturant");
		
	}
	
	
}
public class RoofTopPoolCafe 
{

	public static void main(String[] args) 
	{
		
	}


}