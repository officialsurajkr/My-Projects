package exceptionhandleningTask;

public class EmployeeNameInvalidException extends Exception
{
	public EmployeeNameInvalidException(String message)
	{
		super(message);
	}
}
