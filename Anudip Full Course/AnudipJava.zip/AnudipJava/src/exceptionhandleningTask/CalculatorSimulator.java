package exceptionhandleningTask;
import java.util.Scanner;

class TaxCalculator 
 {
	 public void calculateTax(String empName , boolean isIndian, double empSal)   throws CountryNotvalidException,EmployeeNameInvalidException,TaxNotEligibleException
	 {
		double taxAmount; 
		
		 if(isIndian!=true)
			 throw new CountryNotvalidException("The employee should be an indian citizen for calculating tax");
	 
		 if(empName.equals("null"))
			 throw new EmployeeNameInvalidException("The employee name cannot be empty");
		 
		 if((empSal >100000)  && (isIndian==true) )
			 taxAmount=empSal*8/100;
		 
		 
		 else if((empSal >50000 && empSal<100000) && (isIndian==true))
			 taxAmount=empSal*6/100;
		 
		 else if((empSal>30000 && empSal<50000) && (isIndian==true))
			 taxAmount=empSal*5/100;
		 
		 
		 else if((empSal >=10000 && empSal<=30000) && (isIndian==true))
			 taxAmount=empSal*4/100;
		 else
			 throw new TaxNotEligibleException("Employee does not need to pay tax");
		 
		System.out.println("taxAmount"+taxAmount);
		 }	
	 }

public class CalculatorSimulator 
{
	public static void main(String[] args)  //main () method
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Name: ");
		String	empName=sc.nextLine();
		
		System.out.println("Is employee is Indian");
		boolean isIndian=sc.nextBoolean();
		
		System.out.println("Enter Salary: ");
		double empSal=sc.nextDouble();
		
		//instance class for TaxCalculator
		TaxCalculator taxcal=new TaxCalculator();
		
		//implementing checked exception
		try 
		{
			taxcal.calculateTax(empName, isIndian, empSal);
		}
		catch(CountryNotvalidException e)
		{
			System.out.println(e.getMessage());
		}
		catch(EmployeeNameInvalidException e)
		{
			System.out.println(e.getMessage());
		}
		catch(TaxNotEligibleException e)
		{
			System.out.println(e.getMessage());
		}
		
		
		
				
		
		
	}

}
