package exceptionhandleningTask;

public class CountryNotvalidException extends Exception
{
	public CountryNotvalidException(String message)
	{
		super(message);
	}
}
