package test;

class SCJPQ25 extends Thread {

SCJPQ25() {

setPriority(5);

}

public void run() {

System.out.println("Thread running");

}

public static void main(String args[]) {

SCJPQ25 th1 = new SCJPQ25();

SCJPQ25 th2 = new SCJPQ25();

SCJPQ25 th3 = new SCJPQ25();

th1.start();

th2.start();

th3.start();

}

}
