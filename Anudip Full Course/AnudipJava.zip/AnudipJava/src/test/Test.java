package test;

import java.util.NavigableMap;
import java.util.*;



public class Test implements Runnable   {
	
	
	public static void main (String[] args) throws Exception {

		Thread t = new Thread(new Test());

		t.start();

		System.out.print("Thread Started");

		t.join();

		System.out.print("Completed");

		}

		public void run() {

		for (int i= 0; i< 5; i++) {

		System.out.print(i);

		}

	}
}