package lab_25_8_22;

public class DeleteDuplicateArray 
{
	public static void main(String[] args)
	{
		int arr[]= {1,2,3,4,2,5,6};
		
		int i,j,count=0;
		
		int size=arr.length;
		//find duplicate element
		
				for(i=0 ; i<size; i++)
				{
					for (j=i+1; j<size; j++)
					{
						if(arr[i]==arr[j])
						{	
							count++;
							break;
						}
					}
				}
				System.out.println("total number of duplicate element is "+count);
				
				for(i=1; i<=size; i++)
				{
					arr[i]=arr[i+1];
				}
				//deleting element at given position and decrement size
					size--;
				
				//print array after insert operation
				System.out.println("Array elements after Deletion");
				for(i=0; i<size;i++)
				{
					System.out.print(arr[i]+" ");
				}
				
					
	}}

