package abstractiondemo;
import java.util.Date;
import java.util.Scanner;

class Vaccine {
	Scanner sc =new Scanner(System.in);
	protected int cnt;   
	public Date firstDose() {
		Date firstDate;
		int age, pay;
		String bride;
		
	
		System.out.println("Enter the Nationality: ");
				bride = sc.nextLine();
		
		if(bride.equalsIgnoreCase("Indian"))
		{
			System.out.println("Enter the Age: ");
			age = sc.nextInt();
			if(age>=18)
			{
			
			pay=250;
			
			System.out.println("Get ready for first Dose! \nYou Can take the First Dose.");
			System.out.println("Your Processing Fee is: "+pay+"rs");
			
		     
			}
			else 
			{
			System.out.println("you are not 18 years old");
			System.exit(0);
			}
		
		}
		else
			{
			System.out.println("You can't take the First Dose as you are not indian");
			System.exit(0);
			}
		firstDate=new Date();
		return firstDate;
	}
	public void secondDose() {   
		
			System.out.println("you Can take The 2nd Dose!");
			System.out.println("Your Processing Fee is: 250 rs");
			boosterDose(true);
			
		}
	
	
	public void boosterDose(boolean b) {   //()
	
		if(b==true) {
			System.out.println("you are Eligible for Booster! \nStay Immune and Stay Safe!");
		}
		else if(b==false) {
		
			System.out.println("You can't take the Booster Dose \nFirst of all Take the Second Dose ");
			secondDose();  
	    }
		else System.out.println("Since you did'nt Took the First Dose \nYou are not Eligible for For Booster");
	}
}
public class Vaccination {

	public static void main(String[] args) {
		Vaccine vaccine=new Vaccine();
		Date fdate=vaccine.firstDose();
		Date currentdate=new Date();
		
		int month=(currentdate.getMonth()-fdate.getMonth());
		//System.out.println(month);
		if(month>2)
		vaccine.secondDose();
		else
			System.out.println("you can take second dose after completing two months");
	}

}