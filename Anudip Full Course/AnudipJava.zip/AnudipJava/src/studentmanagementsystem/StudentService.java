package studentmanagementsystem;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentService {

	
//	static Student student[]=new Student[10];
    
//	static int index=0;
//	
//	public static void  createStudent()
//	{
//		int id;
//		String name,address;
//		System.out.println("enter stdent id:");
//		id=sc.nextInt();
//		sc.nextLine();
//		System.out.println("enter stdent name:");
//		name=sc.nextLine();
//		
//		System.out.println("enter stdent address:");
//		address=sc.nextLine();
//		student[index]=new Student(id,name, address);
//		index++;
//		System.out.println("Students has been added successfully");
//		System.out.println("=====================================");
//	}
//	
//	public static void getStudentById(int id) throws StudentNotFoundException
//	{
//		boolean f=false;
//		for(int i=0;i<index;i++) {
//		if(id==student[i].getStudentId())
//		{
//			//System.out.println(student[i]);
//			System.out.println("Student id: "+student[i].getStudentId());
//			System.out.println("Student Name: "+student[i].getStudentName());
//			System.out.println("Student Address: "+student[i].getAddress());
//		    f=true;
//		    break;
//		}
//		
//		}
//		if(f==false)
//			throw new StudentNotFoundException("Student not found with id: "+id);
//	
//		System.out.println("=====================================");
//	}
//	
//	public static void getAllStudents()
//	{
//		for(int i=0;i<index;i++) {
//			System.out.println("Student id: "+student[i].getStudentId());
//			System.out.println("Student Name: "+student[i].getStudentName());
//			System.out.println("Student Address: "+student[i].getAddress());
//		}
//		System.out.println("=====================================");
//		}
	
//	
//	static ArrayList<Student> student=new ArrayList<Student>();
//	static Student stud=new Student();
//	public static void createStudent(Student s)
//	{
//		student.add(s);
//	}
//	
//	public static void getAllStudent()
//	{
//		for(Student stud: student)
//		{
//			System.out.println("Student id: "+stud.getStudentId());
//			System.out.println("Student Name: "+stud.getStudentName());
//			System.out.println("Student Address: "+stud.getAddress());
//		}
//	}
//	
//	public static void updateStudent(int id) throws StudentNotFoundException
//	{
//		for(int i=0;i<student.size();i++)
//		{
//			if(student.get(i).getStudentId()==id)
//			{
//				System.out.println("enter stdent id:");
//				int sid=sc.nextInt();
//				sc.nextLine();
//				System.out.println("enter stdent name:");
//				String name=sc.nextLine();
//				
//				System.out.println("enter stdent address:");
//				String address=sc.nextLine();
//				Student s=new Student(id, name, address);
////			stud.setStudentId(s.getStudentId());
////			stud.setStudentName(s.getStudentName());
////			stud.setAddress(s.getAddress());
//				student.add(s);
//			}
//			else
//			throw new StudentNotFoundException("Student id with "+id+" not found");
//		}
//	}


static ArrayList<Student> student =new ArrayList<Student>();
static Scanner sc=new Scanner(System.in);

public static void  createStudent()
{
	
	int id;
	String name,address;

	System.out.println("enter stdent id:");
	id=sc.nextInt();
	sc.nextLine();
	System.out.println("enter student name:");
	name=sc.nextLine();
	
	System.out.println("enter stdent address:");
	address=sc.nextLine();
	student.add(new Student(id,name, address)) ; //adding data 
	System.out.println("Students has been added successfully");
}


public static void  updateStudentUsingId(int id) throws StudentNotFoundException
{


	boolean status=false;
	for(int i=0;i<student.size();i++) {
		if(id==student.get(i).getStudentId()) //Checking entered id is matching or not
		{
	String name,address;


	System.out.println("enter new stdent id:");
	id=sc.nextInt();
	sc.nextLine();
	System.out.println("enter new stdent name:");
	name=sc.nextLine();
	
	System.out.println("Enter new stdent address:");
	address=sc.nextLine();
	student.set(i, new Student(id,name, address)); //updating data
	
	System.out.println("Students has been Updated successfully");
	status=true;
}
	}
 if(status==false) //if id not found exception will throw
 {
	 //throw new StudentNotFoundException("student not found with id: "+ id);
	 throw new StudentNotFoundException();
 }
	}
//creating method to get student details using id
public static void getStudentById(int id) throws StudentNotFoundException
{
	boolean status=false;
	for(int i=0;i<student.size();i++)
	{
	if(id==student.get(i).getStudentId()) //Checking entered id is matching or not
	{
		//System.out.println(student[i]);
		//printing students data
		System.out.println("Student id: "+student.get(i).getStudentId());
		System.out.println("Student Name: "+student.get(i).getStudentName());
		System.out.println("Student Address: "+student.get(i).getAddress());
		status=true;
		
	}
	
	}
	if(status==false) //if id not found exception will throw
	{
		throw new StudentNotFoundException();
	}
	
	
}
//creating method to print all students data
public static void getAllStudents() {
	//loop to print
	for(int i=0;i<student.size();i++) {
		
			System.out.println("Student id: "+student.get(i).getStudentId());
			System.out.println("Student Name: "+student.get(i).getStudentName());
			System.out.println("Student Address: "+student.get(i).getAddress());
		
		}
}
//creating method to delete data using id
public static void deleteStudentUsingId(int id) throws StudentNotFoundException 
{
	boolean status=false;
	for(int i=0;i<student.size();i++) 
	{
		if(id==student.get(i).getStudentId()) //Checking enter id is exist or not
		{
			student.remove(i); //Deleting data
			System.out.println("Student with ID "+id+" Is deleted succesfully");
			status=true;
		}
	}
	if(status==false) //if entered id not found
	{
		 throw new StudentNotFoundException(); //exception will throw
	 }
}
	}