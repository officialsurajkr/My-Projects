package com.ars.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.ars.entity.Airline;
import com.ars.entity.Flight;
import com.ars.entity.Passenger;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class TicketBookingDTO {
	
	private int ticketId;
	
	@NotNull(message = "{t.noOfP.check}")
	private int no_of_passenger;
	
	@NotNull(message = "{t.fare.check}")
	private double totalFare;
	
	@NotNull(message = "{t.date.check}")
	private Date Date=new Date();

	private Flight flightId;
	
	private Airline airlineId;
	
	private Passenger passengerId;

	



	public TicketBookingDTO(@NotNull(message = "{t.noOfP.check}") int no_of_passenger,
			@NotNull(message = "{t.fare.check}") double totalFare,
			java.util.@NotNull(message = "{t.date.check}") Date date, Flight flightId, Airline airlineId,
			Passenger passengerId) {
		super();
		this.no_of_passenger = no_of_passenger;
		this.totalFare = totalFare;
		Date = date;
		this.flightId = flightId;
		this.airlineId = airlineId;
		this.passengerId = passengerId;
	}
	
	
	

	
	

	
	
	
	

}
