package com.ars.dao;

import com.ars.entity.Admin;


public interface AdminDAO {

	void registerAdmin(Admin admin);
	boolean loginAdmin(String userName,String password);
	Admin updateAdmin(int id,Admin admin);
	Admin  getAdmin(int id);
	void deleteAdmin(int id);
	
}
