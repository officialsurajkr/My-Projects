package com.ars.service;

import com.ars.entity.Admin;
import com.ars.exception.GlobalException;
import com.ars.model.AdminDTO;


public interface AdminService {
	void registerAdmin(Admin admin);
	boolean loginAdmin(String userName,String password);
	AdminDTO updateAdmin(int id,Admin admin);
	AdminDTO getAdminById(int id) throws GlobalException;
	void deleteAdmin(int id);
}
