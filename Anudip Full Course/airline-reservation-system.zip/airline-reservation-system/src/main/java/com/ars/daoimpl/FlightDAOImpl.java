package com.ars.daoimpl;

import java.util.List;

import javax.swing.JOptionPane;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ars.config.HibernateUtil;
import com.ars.dao.FlightDAO;
import com.ars.entity.Admin;
import com.ars.entity.Flight;
import com.ars.exception.GlobalException;



public class FlightDAOImpl implements FlightDAO{
	
	private static final Logger Logger=LoggerFactory.getLogger(FlightDAOImpl.class);

	@Override
	public void saveFlight(Flight flight) {
		try(Session session=HibernateUtil.getSession())
		{
			//adding new flight details
			session.beginTransaction();
			session.save(flight);
			
			//java object saved to database
			session.getTransaction().commit();
			
			Logger.info("new passenger has been added"+flight.toString()
			+" and creation date is: "+ new java.util.Date()+"and creation time is "+new java.util.Timer());
			
			//clear the session
			session.clear();
		}
		catch (HibernateException e) {
			System.out.println("hibernate exception is: "+ e);
		}
			
		catch (Exception e) {
			System.out.println("exception is: "+ e);
		}	
		
	}

	@Override
	public Flight updateFlight(int id, Flight flight) {
		
try(Session session=HibernateUtil.getSession()){
		
			
		
			Flight f=(Flight)session.load(Flight.class, id);
			
			//update existing details with new one
			f.setAvailableSeats(flight.getAvailableSeats());
			f.setTotalSeats(flight.getTotalSeats());
			f.setTravellerClass(flight.getTravellerClass());
			f.setTime(flight.getTime());
			f.setDate(flight.getDate());
			f.setSource(flight.getDestination());
			
			
			session.beginTransaction();
			session.saveOrUpdate(f);
			session.getTransaction().commit();
			
			Logger.info("flight updated successfully"+ f.toString()+ "at:"+ new java.util.Date());
			return f;// return passenger entity
			
		}
		catch (HibernateException e) {
		System.out.println("hibernate exception is: "+ e);
		}
					
		catch (Exception e) {
			System.out.println("exception is: "+ e);
		}
			return null;
	}

	@Override
	public Flight getFlight(int id) {
		try(Session session=HibernateUtil.getSession())
		{
		Flight flight =(Flight)session.get(Flight.class, id);
		Logger.info("flight details fetched successfully"+ flight.toString()+ "at:"+ new java.util.Date());
		return flight;
		}
			 catch (HibernateException e) {
					System.out.println("hibernate exception is: "+ e);
				}
					
				catch (Exception e) {
					System.out.println("exception is: "+ e);
				}	
        
		return null;
	}

	@Override
	public void deleteFlight(int id) {
		try(Session session=HibernateUtil.getSession()){
			
			
			Flight f=session.load(Flight.class, id);
			
			session.beginTransaction();
			int input=JOptionPane.showConfirmDialog(null, "do you want to delete?",
					"select what you want to delete or not?",JOptionPane.YES_NO_OPTION);
				
			if(input==0)
			{
				session.delete(f);
				
			}
			else
			JOptionPane.showMessageDialog(null, "User wants to retain it!!!");
			Logger.info("flight deleted successfully"+ f.toString()+ "at:"+ new java.util.Date());
			session.getTransaction().commit();
			
			}catch (HibernateException e) {
				System.out.println("hibernate exception is: "+ e);
			}
				
			catch (GlobalException e) {
				throw new GlobalException(" id not found");
			}
		
	}

	@Override
	public List<Flight> checkFlight(String from, String to) {
	        try(Session session=HibernateUtil.getSession())
	        {
	        	String q="from Flight as f where f.source=:s and f.destination=:d";
	        	Query query=session.createQuery(q);
	        	query.setParameter("s", from);
	        	query.setParameter("d", to);
	        	List<Flight> flights=query.list();
	        	Logger.info("flight details "+ flights.toString()+ "at:"+ new java.util.Date());
	        	return flights;
	        }
	        catch (HibernateException e) {
				System.out.println("hibernate exception is: "+ e);
			}
				
			catch (Exception e) {
				System.out.println("exception is: "+ e);
			}	
		return null;
	}

}
