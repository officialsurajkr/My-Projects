package com.ars;

import java.time.LocalDate;
import java.util.List;

import javax.swing.JOptionPane;

import com.ars.entity.Flight;
import com.ars.entity.TicketGenerationPdf;
import com.ars.model.TicketBookingDTO;
import com.ars.service.AirlineService;
import com.ars.service.FlightService;
import com.ars.service.TicketService;
import com.ars.serviceimpl.AirlineServiceImpl;
import com.ars.serviceimpl.FlightServiceImpl;
import com.ars.serviceimpl.TicketServiceImpl;

public class CrudTicketBooking 
{
	
	static FlightService fService=new FlightServiceImpl();
	static AirlineService aService=new AirlineServiceImpl();
	static TicketService tService=new TicketServiceImpl();
	
	
	//this method is responsible to book flights tickets
	public static void 	bookFlight()
	{
		List<Flight> flights=fService.checkFlight(JOptionPane.showInputDialog("Enter From","Type here"),
				JOptionPane.showInputDialog("Enter To","Type here"));
		for(Flight flight: flights)
		{
			System.out.println("Flight Id : "+flight.getFlight_id());
			System.out.println("Airline Name : "+flight.getAirline().getAirlineName());
			System.out.println("Flight Date : "+flight.getDate());
			System.out.println("Flight Source : "+flight.getSource());
			System.out.println("Flight Destination : "+flight.getDestination());
			System.out.println("Flight Time : "+flight.getTime());
			System.out.println("Flight Class : "+flight.getTravellerClass());
			System.out.println("Flight AvailableSeats : "+flight.getAvailableSeats());
			
		}
			System.out.println("For booking press Yes");
			String choice=JOptionPane.showInputDialog("Type yes for book flights ","Type here");
			if(choice.equalsIgnoreCase("yes"))
			{
				int flight_id=Integer.parseInt(JOptionPane.showInputDialog("Enter Flight ID","Type here"));
				int no_of_passenger=Integer.parseInt(JOptionPane.showInputDialog("Enter total passenger","Type here"));
			    LocalDate date=LocalDate.parse(JOptionPane.showInputDialog("Enter Date","YYYY-MM-DD"));
			    String pEmail=JOptionPane.showInputDialog("Enter Passenger Email","Type here");
			    String airName=JOptionPane.showInputDialog("Enter AirLine Name","Type here");
			    TicketBookingDTO ticketDTO=tService.bookFlight(flight_id, no_of_passenger, date, pEmail, airName);
			    System.out.println("your booking has done successfully");
			    TicketGenerationPdf.TicketGeneration(ticketDTO);
			
		}
	}
	
	
	
	//this method is responsible to assign flights to airline	
	
		public static void assignAirlineToFlight()
		{
				
			int fId=(Integer.parseInt(JOptionPane.showInputDialog("Enter Flight Id","Type here")));
			int aId=(Integer.parseInt(  JOptionPane.showInputDialog("Enter Airline Id","Type here")));
				aService.assignAirlineToFlight(fId, aId);  //(fId, aId)
				//System.out.println("Flight assign to Airline successfully");
				JOptionPane.showMessageDialog(null, "Flight assign to Airline successfully!");
		}
		
		
		
		public static void cancelTicket()
		{
			
			int ticketId=(Integer.parseInt(JOptionPane.showInputDialog("Enter Ticket Id","Type here")));
			
    		tService.cancelBooking(ticketId);
			JOptionPane.showMessageDialog(null, "Ticket is canceled Successfully!!!!");
			
		}

}
