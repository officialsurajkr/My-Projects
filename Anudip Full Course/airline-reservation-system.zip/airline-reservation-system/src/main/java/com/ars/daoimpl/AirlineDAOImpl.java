package com.ars.daoimpl;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ars.config.HibernateUtil;
import com.ars.dao.AirlineDAO;
import com.ars.entity.Admin;
import com.ars.entity.Airline;
import com.ars.entity.Flight;

public class AirlineDAOImpl implements AirlineDAO{
	
	private static final Logger Logger=LoggerFactory.getLogger(AirlineDAOImpl.class);

	@Override
	public void saveAirline(Airline airline) {
		try(Session session=HibernateUtil.getSession())
		{
			//adding new airline details
			session.beginTransaction();
			session.save(airline);
			
			//java object saved to database
			session.getTransaction().commit();
			
			Logger.info("new airline has been added"+airline.toString()
			+" and creation date is: "+ new java.util.Date()+"and creation time is "+new java.util.Timer());
			
			//clear the session
			session.clear();
		}
		catch (HibernateException e) {
			System.out.println("hibernate exception is: "+ e);
		}
			
		catch (Exception e) {
			System.out.println("exception is: "+ e);
		}	
		
	}

	@Override
	public void assignAirlineToFlight(int flightId, int airId) {
		try(Session session=HibernateUtil.getSession())
		{
		Flight flight=(Flight)session.get(Flight.class, flightId);
		Airline airline =(Airline)session.load(Airline.class, airId);
		
		List<Flight> flights=new ArrayList<>();
		flights.add(flight);
		
		airline.setFlights(flights);
		flight.setAirline(airline);
		
		session.beginTransaction();
		session.saveOrUpdate(airline);
		
		session.getTransaction().commit();
		}
		catch (HibernateException e) {
			System.out.println("hibernate exception is: "+ e);
		}
			
		catch (Exception e) {
			System.out.println("exception is: "+ e);
		}
	}

	@Override
	public Airline getAirlineByName(String name) {
	try(Session session=HibernateUtil.getSession()){
		String query="from Airline a where a.airlineName=:an";
        Query q =session.createQuery(query);
        q.setParameter("an", name);
         Airline airline=(Airline) q.uniqueResult();
         
         Logger.info(airline.toString()+" airline details fetched successfullys at:"+ new java.util.Date());
         return airline;
	}
	catch (HibernateException e) {
		System.out.println("hibernate exception is: "+ e);
	}
		
	catch (Exception e) {
		System.out.println("exception is: "+ e);
	}
		return null;
	}

	@Override
	public Airline updateAirline(int id, Airline airline) {
		
		try(Session session=HibernateUtil.getSession()){
		
			
			Admin ad=(Admin)session.load(Admin.class, id);
			Airline a=(Airline)session.load(Airline.class, id);
			
			//update existing details with new one
			a.setAirlineName(airline.getAirlineName());
			a.setFare(airline.getFare());	
			
			session.beginTransaction();
			session.saveOrUpdate(a);
			session.getTransaction().commit();
			
			Logger.info("airline updated Sucessfully: "+ a.toString()+" at "+ new java.util.Date());
			return a;// return passenger entity
			
		}
		catch (HibernateException e) {
		System.out.println("hibernate exception is: "+ e);
		}
					
		catch (Exception e) {
			System.out.println("exception is: "+ e);
		}
			return null;
	}

	@Override
	public Airline getAirline(int id) {
		
		try(Session session=HibernateUtil.getSession()){
			Airline a=(Airline)session.load(Airline.class, id);
			Logger.info("airline details fetched Sucessfully: "+ a.toString()+" at "+ new java.util.Date());
			return a;
			
			}
			
		catch (HibernateException e) {
			System.out.println("hibernate exception is: "+ e);
		}
			
		catch (Exception e) {
			System.out.println("exception is: "+ e);
		}
			return null;
	}

	@Override
	public void deleteAirline(int id) {
		try(Session session=HibernateUtil.getSession()){
			
			Airline a=session.load(Airline.class, id);
			
			session.beginTransaction();
			int input=JOptionPane.showConfirmDialog(null, "do you want to delete?",
					"select what you want to delete or not?",JOptionPane.YES_NO_OPTION);
				
			if(input==0)
			{
				session.delete(a);
				JOptionPane.showMessageDialog(null, "Object is deleted!!!!");
			}
			else
			JOptionPane.showMessageDialog(null, "User wants to retain it!!!");
			Logger.info("airline deleted Sucessfully: "+ a.toString()+" at "+ new java.util.Date());
			session.getTransaction().commit();
			
			}catch (HibernateException e) {
				System.out.println("hibernate exception is: "+ e);
			}
				
			catch (Exception e) {
				System.out.println("exception is: "+ e);
			}
		
	}
		
	

}
