package com.ars.model;



import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class AdminDTO extends UserDTO
{
	@NotNull(message = "{a.name.check}")
	@Size(min = 2,message = "{a.size.check}")
	private String aname;
    
	
	@NotNull(message = "{a.email.check}")
	@Email
	private String aemail;


	public AdminDTO(@NotNull(message = "{a.name.check}") @Size(min = 2, message = "{a.size.check}") String aname,
					@NotNull(message = "{a.email.check}") @Email String aemail) {
		super();
		this.aname = aname;
		this.aemail = aemail;
	}
	
	
	
	
}
