package com.ars.serviceimpl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ars.dao.FlightDAO;
import com.ars.daoimpl.FlightDAOImpl;
import com.ars.entity.Airline;
import com.ars.entity.Flight;
import com.ars.exception.GlobalException;
import com.ars.model.AirlineDTO;
import com.ars.model.FlightDTO;
import com.ars.service.FlightService;


public class FlightServiceImpl implements FlightService{
	
	private static final Logger Logger=LoggerFactory.getLogger(FlightServiceImpl.class);

	FlightDAO flightDAO=new FlightDAOImpl();
	@Override
	public void saveFlight(Flight flight) {
		flightDAO.saveFlight(flight);
		Logger.info("inside save Flight method: ");
		
	}

	@Override
	public FlightDTO updateFlight(int id, Flight flight) {
	
		Flight f=flightDAO.updateFlight(id, flight);
		Logger.info("inside update Flight method: ");
		
		return new ModelMapper().map(f, FlightDTO.class); //converting entity to DTO
	}

	@Override
	public FlightDTO getFlight(int id) throws GlobalException {
		
		Flight flight=flightDAO.getFlight(id);
		if(flight!=null)
		{
			Logger.info("inside getFlight method: ");
			return new ModelMapper().map(flight,FlightDTO.class);
		}
			throw new GlobalException("Flights details not exist!!");
	}

	@Override
	public void deleteFlight(int id) {
		Logger.info("inside delete Flight method: ");
		flightDAO.deleteFlight(id);
	}

	@Override
	public List<Flight> checkFlight(String from, String to) {
		Logger.info("inside check Flight method: ");
		
		return flightDAO.checkFlight(from, to);
	}

	
	

}
