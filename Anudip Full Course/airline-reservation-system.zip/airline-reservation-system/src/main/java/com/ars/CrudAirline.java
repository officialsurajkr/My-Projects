package com.ars;

import javax.swing.JOptionPane;

import com.ars.entity.Airline;
import com.ars.model.AirlineDTO;
import com.ars.service.AirlineService;
import com.ars.serviceimpl.AirlineServiceImpl;

public class CrudAirline 
{
	static AirlineService aService=new AirlineServiceImpl();
	
			//crud operation of airlines
		public static void airline()
		{
		
			
			String in;
			while(true) {
			System.out.println("============================================================================");
		System.out.println("Press c. for add Airline details\n"
						 + "Press r. for get AIrline details\n "
						 + "Press u.for update Airline details\n"
						 + "Press d.for delete Airline details\n"
						 + "Press q for quit ");
		System.out.println("============================================================================");
		in=JOptionPane.showInputDialog("Enter choice","Type here");
		
		switch(in) {
		
		case "c":
			Airline airline2=new Airline();
			airline2.setAirlineName("Air Asia");
			airline2.setFare(7800.55f);
		    aService.saveAirline(airline2);
		    System.out.println("Airline saved succeessfully");
		    break;
		    
		    
		case "r":
			 try {
			
			 AirlineDTO airlinedto=aService.getAirlineById(Integer.parseInt(JOptionPane.showInputDialog("Enter id", "type here")));
				System.out.println("Passenger details: ");
				System.out.println("Airline Id: "+airlinedto.getId());
				System.out.println("Airline Name: "+airlinedto.getAirlineName());
		        System.out.println("Airline Fare: "+airlinedto.getFare());
		
			}
			catch (Exception e) {
				System.out.println(e);
			}
			
		break;
		    
		    
		    
		    
		case "u":
			
			Airline airline=new Airline();
			
			airline.setAirlineName("Air India");
			airline.setFare(5500.20f);
			 
			AirlineDTO upAirline=aService.updateAirline(Integer.parseInt(JOptionPane.showInputDialog
					("enter id to update", "type here")),airline);
		
			System.out.println("Airline updated successfully");
			
			break;
			
		 case "d":
			 aService.deleteAirline(Integer.parseInt(JOptionPane.showInputDialog("enter id to delete", "type here")));
		break;

			

		case "q":
			
			CrudOperation.AdminOpeartion();
			break;
		}//end of switch
		}//end of while
		}//end of method
}
