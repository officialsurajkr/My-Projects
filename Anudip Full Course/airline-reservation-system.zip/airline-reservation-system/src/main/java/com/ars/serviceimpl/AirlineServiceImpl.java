package com.ars.serviceimpl;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ars.dao.AirlineDAO;
import com.ars.daoimpl.AirlineDAOImpl;
import com.ars.entity.Airline;
import com.ars.exception.GlobalException;
import com.ars.model.AirlineDTO;
import com.ars.service.AirlineService;

public class AirlineServiceImpl implements AirlineService{
	
	private static final Logger Logger=LoggerFactory.getLogger(AirlineServiceImpl.class);


	AirlineDAO airlineDAO=new AirlineDAOImpl();
	
	@Override
	public void saveAirline(Airline airline) {
		airlineDAO.saveAirline(airline);
		Logger.info("inside save Airline method: ");
		
	}

	@Override
	public void assignAirlineToFlight(int flightId, int airId) {
		airlineDAO.assignAirlineToFlight(flightId, airId);
		Logger.info("inside assingAirline method: ");
		
	}

	@Override
	public AirlineDTO updateAirline(int id, Airline airline) {
		
		Airline a=airlineDAO.updateAirline(id, airline);
		Logger.info("inside update Airline method: ");
		return new ModelMapper().map(a, AirlineDTO.class); //converting entity to DTO
	}

	@Override
	public AirlineDTO getAirlineById(int id) throws GlobalException
	{
		Airline airline=airlineDAO.getAirline(id);
		if(airline!=null)
		{
			Logger.info("inside getAirlineById method: ");
			return new ModelMapper().map(airline, AirlineDTO.class);
		}
			throw new GlobalException("Airline details not exist!!");
		}

	@Override
	public void deleteAirline(int id) {
		Logger.info("inside delete Airline method: ");
		airlineDAO.deleteAirline(id);
	}
	

}
