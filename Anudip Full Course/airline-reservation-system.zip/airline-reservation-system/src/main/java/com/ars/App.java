	package com.ars;



import javax.swing.JOptionPane;

import com.ars.entity.Admin;
import com.ars.entity.Passenger;
import com.ars.service.AdminService;
import com.ars.service.PassengerService;
import com.ars.serviceimpl.AdminServiceImpl;
import com.ars.serviceimpl.PassengerServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
	
    public static void main( String[] args )
    {
    	
      mainMenu();
    }
    
    public static void mainMenu()
    {
    	System.out.println("============================================================================");
    	System.out.println("Press A for Admin\n"
    					+  "Press P for Passenger\n"
    					+  "Press Q for exit");
        String choice=JOptionPane.showInputDialog("Enter choice","Type here");
        System.out.println("============================================================================");
       
         switch(choice)
         {
         case "A": mainAdmin();
         break;
         
         case "P": mainUser();
         break;
         
         case "Q": System.exit(0);
         }	
    }
    
    public static void mainAdmin()
    {
              AdminService aService=new AdminServiceImpl();
    	
    	 String choice;
    	   while(true) {
    	    	System.out.println("Press R for Registration\n"
    	    					 + "Press L for Login\n"
    	    					 + "Press Q for exit");
    	        choice=JOptionPane.showInputDialog("Enter choice","Type here");
    	      
    	        switch(choice)
    	        {
    	        
    	        case "R":
    	       
    		      Admin admin=new Admin();
    		     String name=JOptionPane.showInputDialog("Enter  Name","Type here");
    		     String email= JOptionPane.showInputDialog("Enter  Email","Type here");
    		     String username= JOptionPane.showInputDialog("Enter Username","Type here");
    		     String password= JOptionPane.showInputDialog("Enter Password","Type here");
    		//     String role= JOptionPane.showInputDialog("Enter Your Role","Type here");
    		      
    		       admin.setAname(name);
    		       admin.setAemail(email);
    		       admin.setUserName(username);
    		       admin.setPassword(password);
    		       admin.setRole("Admin");
    		        
    		       aService.registerAdmin(admin);
    		       
    		        System.out.println("Admin Registration has done successfully");
    		        System.out.println("Your User Id is "+ admin.getId());
    		        break;
    		        
    	        case "L":
    	        	boolean status=aService.loginAdmin(JOptionPane.showInputDialog("Enter UserName","Type here"),
    	        			JOptionPane.showInputDialog("Enter password","Type here"));
    	        	if(status==true)
    	        	{
    	        		System.out.println("Admin Login Succesfull");
    	        		
    	        		CrudOperation.AdminOpeartion();
    	        	}
    	        		
    	        	else
    	        		System.out.println("Invalid Credentials!!");
    	        	System.exit(0);
    	        	break;
    	        	
    	        case "Q":
    	        	mainMenu();
    	        }
    	       }
    }
    
    public static void mainUser()
    {
    	PassengerService pservice=new PassengerServiceImpl();
        String choice;
       
        	System.out.println("Press R for Registration\n"
        					 + "Press L for Login\n"
        					 + "Press Q for exit");
            choice=JOptionPane.showInputDialog("Enter choice","Type here");
            switch(choice)
            {
            
            case "R":
            	Passenger passenger=new Passenger();
            String name=JOptionPane.showInputDialog("Enter  Name","Type here");
    	    String email= JOptionPane.showInputDialog("Enter  Email","Type here");
    	    String phno= JOptionPane.showInputDialog("Enter Phno","Type here");
    	    String username= JOptionPane.showInputDialog("Enter Username","Type here");
    		String password= JOptionPane.showInputDialog("Enter Password","Type here");
    	  //  String role= JOptionPane.showInputDialog("Enter Your Role","Type here");
    	    
    	        passenger.setName(name);
    	        passenger.setEmail(email);
    	        passenger.setPhno(phno);
    	        passenger.setUserName(username);
    	        passenger.setPassword(password);
    	        passenger.setRole("User");
    	        
    	        //for save passenger,invoking savePassenger() method from service class
    	        pservice.savePassenger(passenger);
    	        
    	        System.out.println("passenger Registration has done successfully");
    	        System.out.println("Your UserId is "+passenger.getId());
    	        break;
    	        
            case "L":
            	boolean status=pservice.login(JOptionPane.showInputDialog("Enter UserName","Type here"),
            			JOptionPane.showInputDialog("Enter password","Type here"));
            	if(status==true)
            	{
            		System.out.println("login succesfull");
            		CrudOperation.passengerOpearation();
            	}
            	else
            		System.out.println("Invalid Credentials!!");
            	System.exit(0);
            	break;
            	
            case "Q":
            	System.exit(0);
            }
        }
    
}
