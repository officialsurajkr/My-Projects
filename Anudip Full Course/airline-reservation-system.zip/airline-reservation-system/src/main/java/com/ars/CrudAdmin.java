package com.ars;

import javax.swing.JOptionPane;

import com.ars.entity.Admin;
import com.ars.model.AdminDTO;
import com.ars.service.AdminService;
import com.ars.serviceimpl.AdminServiceImpl;

public class CrudAdmin
{
	static AdminService aservise=new AdminServiceImpl();
	//this method is responsible to  perform crud operation of admin
	public static void admin()
	{
		String xx;
		while(true) {
		System.out.println("============================================================================");
System.out.println( "Press r. for Read Admin details\n "
				  + "Press u.for Update Admin details\n "
				  + "Press d.for Delete Admin details\n"
				  + "Press q for Quit");
System.out.println("============================================================================");
 xx=JOptionPane.showInputDialog("Enter choice","Type here");

 switch(xx) {
 

 case "r":
	 try {
	 AdminDTO adto=aservise.getAdminById(Integer.parseInt(JOptionPane.showInputDialog("Enter id", "type here")));
	
		System.out.println("Admin details: ");
		System.out.println("Admin Id: "+adto.getId());
		System.out.println("Admin Name: "+adto.getAname());
        System.out.println("Admin Email: "+adto.getAemail());

	}
	catch (Exception e) {
		System.out.println(e);
	}
	
break;
	
 case "u":
	 
	 
	 Admin admin=new Admin();
	 
//	 admin.setAName("Suraj Kumar");
//	 admin.setEmail("surajk@gmail.com");
//	 admin.setUserName("root");
//	 admin.setPassword("root123");
//	 admin.setRole("admin");
	 
	 String name=JOptionPane.showInputDialog("Enter new name","Type here");
     String email= JOptionPane.showInputDialog("Enter new email","Type here");
     String username= JOptionPane.showInputDialog("Enter new  username","Type here");
     String password= JOptionPane.showInputDialog("Enter new password","Type here");
     
     admin.setAname(name);
     admin.setAemail(email);
     admin.setUserName(username);
     admin.setPassword(password);
     admin.setRole("Admin");
     

	AdminDTO upAdmi=aservise.updateAdmin(Integer.parseInt(JOptionPane.showInputDialog
			("enter id to update", "type here")),admin);
	JOptionPane.showMessageDialog(null, "admin updated successfully");

	
break;	

 case "d":
	 aservise.deleteAdmin(Integer.parseInt(JOptionPane.showInputDialog("enter id to delete", "type here")));
	 JOptionPane.showMessageDialog(null, "Object is deleted!!!!");
break;

 case "q":
	 CrudOperation.AdminOpeartion();
	 break;

 }//end of switch
		}
	} //crud admin

}
