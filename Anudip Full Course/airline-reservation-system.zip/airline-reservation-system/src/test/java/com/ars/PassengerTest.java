package com.ars;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Set;

import javax.persistence.PersistenceException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.ars.config.HibernateUtil;
import com.ars.daoimpl.PassengerDAOImpl;
import com.ars.entity.Passenger;
import com.ars.exception.GlobalException;
import com.ars.model.PassengerDTO;
import com.ars.service.FlightService;
import com.ars.service.PassengerService;
import com.ars.serviceimpl.PassengerServiceImpl;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PassengerTest 
{

	private static Validator validator;
	PassengerService passengerService=new PassengerServiceImpl();
	
	private static SessionFactory sessionFactory;
	private Session session;
	
	@BeforeAll
	 static void setUp()
	{
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
		sessionFactory=HibernateUtil.getSessionFactory();
	}

	@BeforeEach
	 void OpenSession()
	{
		session=sessionFactory.openSession();
	}
	
	@AfterEach
	 void closeSession()
	{
		if(session!= null)
			session.close();
		System.out.println("Session closed");
	}
	
	@AfterAll
	 static void tearDown()
	{
		if(sessionFactory!=null)
			sessionFactory.close();
		System.out.println("Session factory closed");
	}
	
//	@Test
//	@DisplayName("Positive Test Case")
//	@Order(1)
//	 void testPassengerNotNull()
//	{
//		PassengerDTO passengerDTO=new PassengerDTO("p", "4567856789", "pallab@gamil.com");
//		
//		Set<ConstraintViolation<PassengerDTO>> constraintViolations =
//			      validator.validate( passengerDTO );
//		 //assertEquals( 1, constraintViolations.size() );
//		assertEquals("Name should be more than 2 characters", constraintViolations.iterator().next().getMessage());
//	}
//	
//	@Test
//	@DisplayName("Negative Test Case")
//	@Order(2)
//	 void PassengerEmailTest()
//	{
//		PassengerDTO passengerDTO=new PassengerDTO("p", "4567856789", null);
//		Set<ConstraintViolation<PassengerDTO>> constraintViolations =
//			      validator.validate( passengerDTO );
//		assertEquals("Email Can Not Be Blank", constraintViolations.iterator().next().getMessage());
//	}
	
//	@Test
//	@DisplayName("tetsing Add Passenger ")
//	@Order(3)
//	void testSavePassenger()
//	{
//		//Change email before run because email is set as UniqueConstraint
//		System.out.println("..........Running TestSavePassenger.............");
//		Transaction tx=session.beginTransaction();
//		Passenger pass=Passenger.builder().name("priya").email("priyaa@gmail.com").
//				phno("9906453678").UserName("priya").password("priya12").role("user").build();
//		
//		
//		
//	Integer i=(Integer) session.save(pass);
//	tx.commit();
////	check flight is greater than 0
//	assertThat(i>0).isTrue();
//		
//	}
//	
//	@Test
//	@DisplayName("tetsing Update Passenger ")
//	@Order(4)
//	void testUpdatePassenger()
//	{
//		//Change email before run because email is set as UniqueConstraint
//		System.out.println("..........Running TestUpdatePassenger.............");
//		Transaction tx=session.beginTransaction();
//		Passenger pass=Passenger.builder().name("shawain").email("shawinn@gmail.com").
//				phno("9906478456").UserName("shawin").password("shawin123").build();
//		session.save(pass);
//		pass.setName("shawin p");
//		
//		assertThat(pass.getPhno()).isEqualTo("9906478456");
//	}
	
//	@Test
//	@DisplayName("tetsing UpdatePassengerUsingService ")
//	@Order(5)
//	 void testUpdatePassengerUsingService()
//	{
//		System.out.println("..........Running TestUpdatePassengerUsingService.............");
//		Transaction tx=session.beginTransaction();
//		Passenger p=new Passenger();
//		p.setName("shawin pradhan");
//		p.setEmail("shawin.p@gmail.com");
//		p.setPhno("7895678923");
//		PassengerDTO pdto=passengerService.updatePassenger(25, p);
//		
//		
//		assertThat(pdto.getName()).isEqualTo("shawin pradhan");
//	}
//	
//	
//	
//	
//	
//	
//	@Test
//	@DisplayName("testing getPassengerById ")
//	@Order(6)
//	 void testGetPassengerById() {
//		PassengerDTO pdto =passengerService.getPassengerById(12);
//		assertThat(pdto.getName()).isEqualTo("Mohan");
//	}
//	
	@Test
	@DisplayName("testing delete passenger")
	@Order(7)
	 void testDeletePassenger() {
		
		passengerService.deletePassenger(27);
		
		assertThrows(GlobalException.class, ()-> passengerService.getPassengerById(27));
//		
//	
//		
//		
}
	
	
	
	
}
