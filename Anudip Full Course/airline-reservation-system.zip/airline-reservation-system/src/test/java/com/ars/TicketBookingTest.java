package com.ars;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.modelmapper.ModelMapper;

import com.ars.config.HibernateUtil;
import com.ars.entity.Airline;
import com.ars.entity.Flight;
import com.ars.entity.TicketBooking;
import com.ars.exception.GlobalException;
import com.ars.model.AirlineDTO;
import com.ars.model.FlightDTO;
import com.ars.model.TicketBookingDTO;
import com.ars.service.AirlineService;
import com.ars.service.FlightService;
import com.ars.service.TicketService;
import com.ars.serviceimpl.AirlineServiceImpl;
import com.ars.serviceimpl.FlightServiceImpl;
import com.ars.serviceimpl.TicketServiceImpl;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TicketBookingTest 
{
	
	FlightService flightService=new FlightServiceImpl();
	AirlineService airlineService=new AirlineServiceImpl();
	TicketService tService=new TicketServiceImpl();
	Airline airline=new Airline();
	private static Validator validator;
	private static SessionFactory sessionFactory;
	private Session session;
	
	@BeforeAll
	public static void setUp()
	{
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
		sessionFactory=HibernateUtil.getSessionFactory();
	}

	@BeforeEach
	public void OpenSession()
	{
		session=sessionFactory.openSession();
	}
	
	@AfterEach
	public void closeSession()
	{
		if(session!= null)
			session.close();
		System.out.println("Session closed");
	}
	
	@AfterAll
	public static void tearDown()
	{
		if(sessionFactory!=null)
			sessionFactory.close();
		System.out.println("Session factory closed");
	}
	
//	@Test
//	@DisplayName("testing booking flight ticket")
// 	@Order(1)
//	void testTicketBooking()
//	{
//			
//		TicketBookingDTO td	=tService.bookFlight(1, 5, LocalDate.parse("2022-11-12"), "mohan@gmail.com", "air asia");
//		
//		assertNotNull(td);
//	}
	
	
	@Test
	@DisplayName("testing cancel flight")
 	@Order(2)
	
	 void testCancelsFlight() {
		
		tService.cancelBooking( 42867);  //give ticket id to delete
		
		assertThrows(GlobalException.class, ()-> flightService.getFlight( 42867));		
	}
	
	
	
	@Test
	@DisplayName("testing AssignAirlineToFlight ")
 	@Order(3)
	void testAssignAirlineToFlight()
	{
		airlineService.assignAirlineToFlight(3,3);
		assertThat(flightService.getFlight(3).getAirline().getAirlineName()).isEqualTo("Air India");
	}
	
	@Test
	@DisplayName("negative test case ")
 	@Order(4)
	void testAssignAirlineToFlights()
	{
		airlineService.assignAirlineToFlight(3,4);
		assertThat(flightService.getFlight(3).getAirline().getAirlineName()).isEqualTo("Air India");
	}


}
