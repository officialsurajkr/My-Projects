package com.ars;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.ars.config.HibernateUtil;
import com.ars.entity.Admin;
import com.ars.entity.Passenger;
import com.ars.exception.GlobalException;
import com.ars.model.AdminDTO;
import com.ars.model.PassengerDTO;
import com.ars.service.AdminService;
import com.ars.serviceimpl.AdminServiceImpl;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AdminTest 
{
	private static Validator validator;
	
	AdminService adminService=new AdminServiceImpl();
	
	private static SessionFactory sessionFactory;
	private Session session;
	
	@BeforeAll
	public static void setUp()
	{
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
		sessionFactory=HibernateUtil.getSessionFactory();
	}

	@BeforeEach
	public void OpenSession()
	{
		session=sessionFactory.openSession();
	}
	
	@AfterEach
	public void closeSession()
	{
		if(session!= null)
			session.close();
		System.out.println("Session closed");
	}
	
	@AfterAll
	public static void tearDown()
	{
		if(sessionFactory!=null)
			sessionFactory.close();
		System.out.println("Session factory closed");
	}
	
	@Test
	@DisplayName("Positive Test Case")
	@Order(1)
	 void testAdminNotNull()
	{
		
		AdminDTO admindto=new AdminDTO("r","ram@gmail.com");
		
		Set<ConstraintViolation<AdminDTO>> constraintViolations =
			      validator.validate( admindto );
		 //assertEquals( 1, constraintViolations.size() );
		assertEquals("AdminName should be more than 2 characters", constraintViolations.iterator().next().getMessage());
	}
	
	
	@Test
	@DisplayName("Negative Test Case")
	@Order(2)
	 void testAdminEmail()
	{
		AdminDTO admindto=new AdminDTO("p",  null);
		
		Set<ConstraintViolation<AdminDTO>> constraintViolations =
			      validator.validate( admindto );
		assertEquals("AdminName should be more than 2 characters", constraintViolations.iterator().next().getMessage());
	}
	
	
	@Test
	@DisplayName("tetsing Add Admin ")
	@Order(3)
	 void testSaveAdmin()
	{
		System.out.println("..........Running TestSaveAdmin.............");
		Transaction tx=session.beginTransaction();
		Admin ad=Admin.builder().aname("Suraj Kumar").aemail("suraj@gmail.com").UserName("suraj").
				password("suraj123").role("admin").build();			
			
		Integer i=(Integer) session.save(ad);
		tx.commit();
		//check admin is greater than 0
		assertThat(i>0).isTrue();
		
	}
	
	
	
	@Test
	@DisplayName("tetsing Update Admin ")
	@Order(4)
	 void testUpdateAdmin()
	{
		System.out.println("..........Running TestUpdateAdmin.............");
		Transaction tx=session.beginTransaction();
		Admin ad=Admin.builder().aname("Suraj Kumar").aemail("suraj@gmail.com").UserName("suraj").
			password("suraj123").role("admin").build();
		session.save(ad);
		ad.setAname("Suraj kumar chauhan");
		
		assertThat(ad.getAname()).isEqualTo("Suraj kumar chauhan");
	}
	
	
	@Test
	@DisplayName("tetsing UpdateAdminUsingService ")
	@Order(5)
	void testUpdateAdminUsingService()
	{
		System.out.println("..........Running TestUpdateAdminUsingService.............");
		Transaction tx=session.beginTransaction();
		
		Admin a=new Admin();
		
		a.setAname("rakesh Kumar");
		a.setAemail("rakesh@gmail.com");
		a.setUserName("rakesh");
		a.setPassword("rakesh123");
		a.setRole("admin");
		
		AdminDTO adto=adminService.updateAdmin(22, a);
		
		//testing update admin by id
		assertThat(adto.getAname()).isEqualTo("rakesh Kumar");
	}
	
	
	@Test
	@DisplayName("tetsing GetAdminById ")
	@Order(6)
	 void testGetAdminById() {
		
		AdminDTO adto=adminService.getAdminById(2);
		assertThat(adto.getAname()).isEqualTo("ram");
	}
	
	@Test
	@DisplayName("testing delete airline")
	@Order(7)
	 void testDeleteFlight() {
		
		adminService.deleteAdmin(24);
		
		assertThrows(GlobalException.class, ()-> adminService.getAdminById(24));		
	}
	
	
	
	
	
}
