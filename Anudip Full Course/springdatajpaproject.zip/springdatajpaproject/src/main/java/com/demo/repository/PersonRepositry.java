package com.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.demo.entities.Person;

public interface PersonRepositry extends JpaRepository<Person, Long>
{
	public List<Person> findByName(String name);
	public List<Person> findByNameAndEmail(String name, String email);
	public List<Person> findByNameOrEmail(String name, String email);
	
	@Query("select p from Person p")
	public List<Person> getAllPerson();
	
	@Query("select p from Person p where p.email=?1")
	public List<Person> getPersonByEmail(String email);
	
	@Query("select p from Person p where p.name=:n")
	public Person getPersonByName(@Param("n") String name);  //@param will bind the query annotation with parameter
	
	
	@Query("select p from Person p where p.name=:n and p.id=:i")
	public Person getPersonByNameAndEmail(@Param("n") String name,@Param("i") long id);
	
	
	//sql query
	@Query(value="select * from Person",nativeQuery =true)
	public List<Person> getPersons();
	
}
