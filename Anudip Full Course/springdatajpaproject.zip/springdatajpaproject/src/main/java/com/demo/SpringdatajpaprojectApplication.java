package com.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demo.entities.Person;
import com.demo.repository.PersonRepositry;

@SpringBootApplication
public class SpringdatajpaprojectApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringdatajpaprojectApplication.class, args);
	}
	
	@Autowired
	PersonRepositry personRepositry;
	@Override
	public void run(String... args) throws Exception {
		
	//	Person person=new Person();
		
//		person.setName("islam");
//		person.setEmail("islam@gmail.com");
//		
//		Person person1=new Person();
//		
//		person1.setName("ritesh");
//		person1.setEmail("ritesh@gmail.com");
//		
//		Person person2=new Person();
//		
//		person2.setName("sagar");
//		person2.setEmail("sager@gmail.com");
//		
//		Person person3=new Person();
//		
//		person3.setName("suraj");
//		person3.setEmail("suraj@gmail.com");
//		
//		//save multiple objects
//		
//		List<Person> persons=List.of(person,person1,person2,person3);
//		List<Person> result=personRepositry.saveAll(persons);
//		
//		System.out.println("save all objects");
//		//fetch all objects
//		
//		result.forEach(p ->
//		{
//			
//			System.out.println(p);
//		});
//		
		
		
		//fetch data by id
//			Optional<Person> optional =personRepositry.findById(1L);
//			Person p =optional.get();
//			System.out.println(p);
//		
		
		
		//fetch all data from database
//		List<Person> plist=personRepositry.findAll();
//		
//		System.out.println("list of person");
//		
//		plist.forEach(p ->
//		{
//			System.out.println(p);
//		});
//		
		
		// update person by id
		
//		Optional<Person> optional =personRepositry.findById(1L);
//			Person person =optional.get();
//			
//			person.setName("Suraj Kumar");
//			person.setEmail("suraj.k@gmail.com");
//			
//			Person p=personRepositry.save(person);
//			System.out.println(p+ " is updated succesfully");
//		
		
//		//delete by id
//		 personRepositry.deleteById(5L);
//		 System.out.println("Object is deleted sucessfully");
//		 
//		 //delete all 
//		 personRepositry.deleteAll();
//		 System.out.println("All Object is deleted sucessfully");
		
		
		//Custom finder method
		
//		//find by name
//		List<Person> person1 =personRepositry.findByName("Suraj Kumar");
//		
//		person1.forEach(p1 ->
//		{
//			System.out.println(p1);
//		});
//		
//		
//		//find by nameAndEmail
//		List<Person> person2 =personRepositry.findByNameAndEmail("Suraj Kumar","suraj.k@gmail.com");
//				
//				person2.forEach(p2 ->
//				{
//					System.out.println(p2);
//				});
//				
//				
//				
//				//find by nameAndEmail
//				List<Person> person3 =personRepositry.findByNameOrEmail("Suraj Kumar","islam@gmail.com");
//								
//				person3.forEach(p3 ->
//					{
//						System.out.println(p3);
//					});
		
		
//		List<Person> person4=personRepositry.getAllPerson();
//			person4.forEach(p4 ->
//			{
//				System.out.println(p4);
//			});
//		
		
//			List<Person> person5=personRepositry.getPersonByEmail("suraj.k@gmail.com");
//			person5.forEach(p5 ->
//			{
//				System.out.println(p5);
//			});
//		
		
//		//getPersonByName
//		Person person6 =personRepositry.getPersonByName("Suraj Kumar");
//		System.out.println(person6);
		
		//getPersonByNameAndEmail
//		Person person7 =personRepositry.getPersonByNameAndEmail("Suraj Kumar", 1);
//		System.out.println(person7);
		
		
		List<Person>person8=personRepositry.getPersons();
		person8.forEach(p8 ->
		{
			System.out.println(p8);
		});
//		
	}

}
