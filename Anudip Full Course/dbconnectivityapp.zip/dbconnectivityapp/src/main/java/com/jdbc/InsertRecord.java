package com.jdbc;

import java.sql.Connection;
import java.sql.Statement;

public class InsertRecord 
{
	public static void main(String[] args) {
		
	
	try (Connection con=DatabaseConnection.getDbConnection())
	{
		//static quarry-you know values at the compilation time,need to use statement
		
		Statement st=con.createStatement();
		String query="insert into employee values(101,'chandan','chandan@gmail.com',3500)";
		
		int row=st.executeUpdate(query);
		
		System.out.println(row+" record inserted succesfully");
	} catch (Exception e) {
		e.printStackTrace();
	}
}
}