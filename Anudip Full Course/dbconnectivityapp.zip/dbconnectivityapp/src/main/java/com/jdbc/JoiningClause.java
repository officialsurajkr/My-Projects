package com.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class JoiningClause 
{
	public static void main(String[] args) {
		
		try(Connection con=DatabaseConnection.getDbConnection();
				Scanner sc=new Scanner(System.in))
		{
			//creating table
			
//			Statement st=con.createStatement();
//			String queary="create table account(Id int primary key auto_increment,accNum int,"
//					+ "emp_id int,foreign key(emp_id) references employee(id))";
//			int row=st.executeUpdate(queary);
//			System.out.println(row+"table is created succesfully");
			
			
			//inserting data
//			Statement st2=con.createStatement();
//			String q="insert into account(accNum,emp_id) values(267756,101)";
//			int row=st2.executeUpdate(q);
//			System.out.println(row+ " record inserted succesfully");
		
			
			//using getting data with foreign key
//			Statement st3=con.createStatement();
//
//			String sql="select e.name, e.salary, a.accNum from employee e,"
//			+ "account a where e.id=a.emp_id";
//
//			ResultSet rs=st3.executeQuery(sql);
			
			
			//using inner join
			Statement st4=con.createStatement();
			String sql="select e.name, e.salary, a.accNum from employee e inner join "
			+ "account a on e.id=a.emp_id";

			ResultSet rs=st4.executeQuery(sql);

			while(rs.next())
			{
			System.out.println("employee name: "+ rs.getString("name"));
			System.out.println("employee salary: "+ rs.getInt("salary"));
			System.out.println("Account number: "+ rs.getInt("accNum"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
