package com.jdbc;

import java.sql.Connection;
import java.sql.Statement;

public class CreateTableEx 
{
	public static void main(String[] args) 
	{
		//try with resource
		try (Connection conn=DatabaseConnection.getDbConnection())
		{
			//create Statement
			Statement st=conn.createStatement();
			
			//Write/create Query
			
			String sql="create table employee(id int primary key,name varchar(50) not null,"
					+ "email varchar(70) not null,salary int not null)";
			
			//execute quary
			st.executeUpdate(sql);
			
			System.out.println("Table create succesfully!!");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
//		finally {
//			try {
//				conn.close();
//			} catch (Exception e2) {
//				// TODO: handle exception
//			}
//			
//		}
	}

}
