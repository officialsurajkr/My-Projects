package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateEmployee
{
	public static void main(String[] args)
	{
		try(Connection con = DatabaseConnection.getDbConnection();
				Scanner sc = new Scanner(System.in))
		{
			System.out.println("Enter name:");
			String name = sc.nextLine();
			
			System.out.println("Enter email:");
			String email=sc.nextLine();
			
			System.out.println("Enter salary:");
			int salary=sc.nextInt();
			
			String query="update employee set name='"+name+"',email='"+email+"', "+ "salary='"+salary+"' where id=?";
			
			PreparedStatement ps = con.prepareStatement(query);
			
			System.out.println("Enter id:");
			int id=sc.nextInt();
			
			ps.setInt(1, id);
			int row=ps.executeUpdate();
			System.out.println(row+ " row is updated successfully");
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
	}
}
