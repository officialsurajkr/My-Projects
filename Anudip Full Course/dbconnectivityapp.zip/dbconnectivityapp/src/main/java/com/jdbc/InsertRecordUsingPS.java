package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class InsertRecordUsingPS 
{
public static void main(String[] args) {
	try (Connection con=DatabaseConnection.getDbConnection();
			Scanner sc=new Scanner(System.in))
	{
		String sql="insert into employee values(?,?,?,?)";
		//insert into employee values(101,'Islam','islam@gmail.com',35000);
		PreparedStatement ps=con.prepareStatement(sql);
		System.out.println("Enter Id: ");
		int id=sc.nextInt();
		
		sc.nextLine();
		
		System.out.println("Enter Name: ");
		String name=sc.nextLine();
		
		System.out.println("Enter Email: ");
		String email=sc.nextLine();
		
		System.out.println("Enter Salary: ");
		int salary=sc.nextInt();
		
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.setString(3, email);
		ps.setInt(4, salary);
		
		int r = ps.executeUpdate();
		System.out.println(r+ " record is inserted successfully...");
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	}
}

