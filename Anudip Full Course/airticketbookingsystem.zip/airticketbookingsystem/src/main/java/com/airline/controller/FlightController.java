package com.airline.controller;

import java.util.List;

import javax.servlet.ServletException;
import javax.validation.Valid;

import org.springframework.aop.ThrowsAdvice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.exception.GlobalException;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.FlightDTO;
import com.airline.model.PassengerDTO;
import com.airline.service.FlightService;
import com.airline.util.FlightConverter;

@RestController
@RequestMapping("/api")
public class FlightController {

	@Autowired
	FlightService flightService;
	
	@Autowired
	FlightConverter flightConverter;
	
	@PostMapping("/saveFlight/{role}")
	public ResponseEntity<?> saveFlight(@PathVariable("role") String role, @RequestBody FlightDTO flightdto)
	{
		final Flight flight=flightConverter.covertToFlightEntity(flightdto);
		if(role.equalsIgnoreCase("admin"))
		{
		return new ResponseEntity<FlightDTO>(flightService.saveFlight(flight),HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<String>("You are not admin",HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/assignAirlineToFlight/{fid}/{aid}/{role}")
	public ResponseEntity<?> assignAirlineToFlight(@PathVariable("role") String role,@PathVariable("fid") int flightId, 
			@PathVariable("aid") int airId)
	{
	if(role.equalsIgnoreCase("admin"))
	
	{
		return new ResponseEntity<FlightDTO>(flightService.assignAirlineToFlight(flightId, airId),
				HttpStatus.OK);
	}
	else
	{
		return  new ResponseEntity<String>("You are not admin",HttpStatus.BAD_REQUEST);
	}
	
}
	@GetMapping("/searchFlight/{source}/{destination}")
	public List<FlightDTO> searchFlight(@PathVariable("source") String source,
			@PathVariable("destination") String destination)
	{
		return flightService.searchFlight(source, destination);
	}
	
	//build update flight REST API
		//localhost:8086/updateFlight/2
		@PutMapping("/updateFlight/{id}/{role}")
		public ResponseEntity<?> updateFlight(@Valid @PathVariable("role") String role,@PathVariable("id") int id,
			@RequestBody FlightDTO flightDTO )
		{
			if(role.equalsIgnoreCase("admin"))
				
			{
			
			final Flight flight =flightConverter.covertToFlightEntity(flightDTO);
			return new ResponseEntity<FlightDTO>(flightService.updateFlight(id, flight),
					HttpStatus.OK);
		}
			else
			{
				return  new ResponseEntity<String>("You are not admin",HttpStatus.BAD_REQUEST);
			}
			
		}
	
	
	
		//build GET flight by id REST API
		@GetMapping("/getFlightById/{id}")
		public FlightDTO getFlightById(@PathVariable int id)
		{
			
			return flightService.getFlightById(id);
			
			}
			

		
		//build GET ALL Flight details REST API
				@GetMapping("/getAllFlight")
				public List<FlightDTO> getAllFlight()
				{
					return flightService.getAllFlight();
				}
				
		 //build delete flight REST API
				@DeleteMapping("/deleteFlight/{id}/{role}")
				public String deleteFlight( @PathVariable("role") String role,@PathVariable int id) 
				{
				if(role.equalsIgnoreCase("admin"))
						
					{
					return flightService.deleteFlight(id);
				}
					else
					{
						String result="You are not admin";
						return result;			
					}
					
				}
	
	
	
	
}
