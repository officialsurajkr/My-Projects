package com.airline.model;

import java.time.LocalDate;
import java.util.Date;

import javax.validation.constraints.NotNull;

import com.airline.entity.Airline;


import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
@Data
public class FlightDTO {
	private int flight_id;

	  @NotNull(message = "Available Seats can't be null")
	private int availableSeats;

	  @NotNull(message = "total Seats can't be null")
	private int totalSeats;
	
	  @NotNull(message = "traveller Class can't be null")
	private String travellerClass;

	  @NotNull
	private String time;

	  @NotNull
	private LocalDate date;

	  @NotNull
	private String source;
	
	  @NotNull
	private String destination;

	private Airline airline;
}
