package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Admin;

import com.airline.exception.ResourceNotFoundException;
import com.airline.model.AdminDTO;
import com.airline.repository.AdminRepository;

import com.airline.service.AdminService;
import com.airline.util.AdminConverter;


@Service
public class AdminServiceImpl implements AdminService
{
	//logger statically created
			private static final Logger L=LoggerFactory.getLogger(AdminService.class);
			
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private AdminConverter adminconverter;
	
	//Service layer for createAdmin 
	@Override
	public String createAdmin(Admin admin) {

		String message=null;
		admin.setUserName(admin.getUserName());
		admin.setPassword(admin.getPassword());
		admin.setRole(admin.getRole());
		
		adminRepository.save(admin);
		L.info("Admin"+admin.toString()+" added at "+ new java.util.Date());
		
		if (admin!=null)
		{
			message="Admin saved Successfully!!";
		}
		L.info("Getting All Admin Details By "+admin+ admin.toString() +" at "+ new java.util.Date());
		return message;
		
		
		
	}
	//Service layer for updateAdmin
	@Override
	public AdminDTO updateAdmin(int id, Admin admin) {
		//we need to check whether passenger with given id is exist in DB or not
		
				Admin existingAdmin=adminRepository.findById(id).orElseThrow(()->
				new ResourceNotFoundException("Admin", "id", id));
				
				//we will get data from client and set in existing passenger
				existingAdmin.setAname(admin.getAname());
				existingAdmin.setAphno(admin.getAphno());
				existingAdmin.setAemail(admin.getAemail());
				existingAdmin.setUserName(admin.getUserName());
				existingAdmin.setPassword(admin.getPassword());
				existingAdmin.setRole(admin.getRole());
				
				adminRepository.save(existingAdmin);
				L.info("Admin"+admin.toString()+" updated at "+ new java.util.Date());
				
				return adminconverter.convertToAdminDTO(existingAdmin);
	}
	
	//Service layer for getAdminById
	@Override
	public AdminDTO getAdminById(int id) {
		Admin admin=adminRepository.findById(id).orElseThrow(()->
        new ResourceNotFoundException("Passenger", "id", id));
		L.info("Getting Admin By "+id+" at "+ new java.util.Date());
		return adminconverter.convertToAdminDTO(admin);
	}
	
	//Service layer for getAllAdmin
	@Override
	public List<AdminDTO> getAllAdmin() {
		List<Admin> admin=adminRepository.findAll();
		
		List<AdminDTO> adminDTO=new ArrayList<>();
		for(Admin ad: admin)
		{
			adminDTO.add(adminconverter.convertToAdminDTO(ad));
		}
		L.info("Getting all Admin  "+admin.toString()+" at "+ new java.util.Date());
		return adminDTO;
	}
	
	//Service layer for deleteAdmin
	@Override
	public String deleteAdmin(int id) {
		String msg=null;
		Optional<Admin> opAdmin =adminRepository.findById(id);
		if(opAdmin.isPresent())
		{
			adminRepository.deleteById(id);
			
			msg="Record deleted successfully!!";
			L.info("Deleting  Admin by "+id +" at "+ new java.util.Date());
		}
		else
		{
			throw new ResourceNotFoundException("Passenger", "ID", id);
		}
		return msg;
	}

	//Service layer for getAdminByName
	@Override
	public List<AdminDTO> getAdminByName(String aname) {
		List<Admin> admin=adminRepository.getAdminByName(aname);
		
		List<AdminDTO> aDTO=new ArrayList<>();
		for(Admin a: admin)
		{
			aDTO.add(adminconverter.convertToAdminDTO(a));
		}
		L.info("Getting Admin Details By "+aname+ admin.toString() +" at "+ new java.util.Date());
		return aDTO;
	}
	
	//Service layer for getAdminByEmail
	@Override
	public AdminDTO getAdminByEmail(String aemail) {
		Admin admin=adminRepository.getAdminByEmail(aemail);
		L.info("Getting  Admin Details By "+aemail+ admin.toString() +" at "+ new java.util.Date());
		return adminconverter.convertToAdminDTO(admin);
	}

}
