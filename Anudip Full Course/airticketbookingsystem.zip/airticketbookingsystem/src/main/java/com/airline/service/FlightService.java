package com.airline.service;

import java.util.List;

import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.model.FlightDTO;
import com.airline.model.PassengerDTO;

public interface FlightService {
FlightDTO saveFlight(Flight flight);
FlightDTO assignAirlineToFlight(int flightId, int airlineId);
List<FlightDTO> searchFlight(String source , String destination);
FlightDTO updateFlight(int id, Flight flight );
FlightDTO getFlightById(int id);
List<FlightDTO> getAllFlight();
String deleteFlight(int id);

}
