package com.airline.model;



import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Data

public class PassengerDTO extends UserDTO{
	
	@NotNull
	@Size(min = 2, message = "name should have minimum 2 characters ")
	private String name;

	@NotNull
	@Pattern(regexp = "^\\d{10}$", message = "Phone number should have 10 digits")
	private String phno;

	@NotNull
	@Email
	private String email;

	
	
	
	
}
