package com.airline.serviceImpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.entity.TicketBooking;
import com.airline.entity.TicketGenerationPdf;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.TicketBookingDTO;
import com.airline.repository.AirlineRepository;
import com.airline.repository.FlightRepository;
import com.airline.repository.PassengerRepository;
import com.airline.repository.TicketBookingRepository;
import com.airline.service.AdminService;
import com.airline.service.TicketBookingService;
import com.airline.util.TicketBookingConverter;

@Service
public class TicketBookingServiceImpl implements TicketBookingService{
	
	//logger statically created
	private static final Logger L=LoggerFactory.getLogger(TicketBookingService.class);

	@Autowired
	TicketBookingRepository ticketBookingRepository;
	
	@Autowired
	FlightRepository  flightRepository;
	
	@Autowired
	PassengerRepository passengerRepository; 
	
	@Autowired
	TicketBookingConverter ticketBookingConverter;
	
	@Autowired
	AirlineRepository airlineRepository;
	
	@Autowired
	TicketGenerationPdf ticketGenerationPdf;
	
	
	//Service layer for bookFlight
	@Override
	public String bookFlight(int fid,int pid,TicketBooking ticketBooking) {
		String message=null;
		 Flight flight =flightRepository.findById(fid).get();
		    Passenger passenger= passengerRepository.findById(pid).get();
		    
		    if(flight.getSource().equals(ticketBooking.getSource()) &&
		       flight.getDestination().equals(ticketBooking.getDestination()))
		    {
		    	LocalDate fDate=flight.getDate();
		    	LocalDate bookingDate=LocalDate.now();
		    	if(!bookingDate.isAfter(fDate))
		    	{
		   
		   int total_Seat = flight.getAvailableSeats()- ticketBooking.getNo_of_passenger();
		    flight.setAvailableSeats(total_Seat);
		   ticketBooking.setTotalFare(flight.getAirline().getFare()*
				   ticketBooking.getNo_of_passenger());
		 
		   ticketBooking.setFId(flight);
		   ticketBooking.setPId(passenger);
		   ticketBooking.setAId(ticketBooking.getFId().getAirline());
		   TicketBooking booked=ticketBookingRepository.save(ticketBooking);
		   
		   L.info("Ticket booked"+" at "+ new java.util.Date());
		   
		   if(booked!=null)
			   message="Ticket has booked successfully \n booking details  generated in pdf form ";
		   			TicketGenerationPdf.TicketGeneration(ticketBooking);
		    }
		    	else {
		    		message="you have to book before travel date";
		    	}
		    }
		   else
			   message="please enter correct source or desitination";
		    	return message;
		    
	}


	@Override
	public TicketBookingDTO getBoardingPass(int id) {
		TicketBooking ticketBooking =ticketBookingRepository.findById(id).orElseThrow(()->
        new ResourceNotFoundException("TicketBooking", "id", id));
		L.info("Getting Booking details By "+id+" at "+ new java.util.Date());
		return ticketBookingConverter.convertToTicketBookingDTO(ticketBooking);
	}


	@Override
	public String cancelBooking(int id) {
		String msg=null;
		Optional<TicketBooking> ticket = ticketBookingRepository.findById(id);
		if(ticket.isPresent())
		{
			int nop = ticket.get().getNo_of_passenger();
			ticket.get().getFId().setAvailableSeats((ticket.get().getFId().getAvailableSeats() + nop));
			ticketBookingRepository.deleteById(id);
			msg="Your booking is cancelled!!";
		}
		else
			throw new ResourceNotFoundException("Ticket", "id", id);
		return msg;
	}


	@Override
	public List<TicketBookingDTO> getAllBookingTicket() {
		List<TicketBooking> ticket=ticketBookingRepository.findAll();
		
		List<TicketBookingDTO> ticketBookingDTOs=new ArrayList<>();
		for(TicketBooking t: ticket)
		{
			ticketBookingDTOs.add(ticketBookingConverter.convertToTicketBookingDTO(t));
		}
		
		return ticketBookingDTOs;
	}

	

	
}
