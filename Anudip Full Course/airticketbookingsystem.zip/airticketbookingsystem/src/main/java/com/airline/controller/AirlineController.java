package com.airline.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airline.entity.Airline;
import com.airline.entity.Passenger;
import com.airline.model.AirlineDTO;
import com.airline.model.PassengerDTO;
import com.airline.service.AirlineService;

import com.airline.util.AirlineConverter;


@RestController
@RequestMapping("/api")
public class AirlineController 
{
	@Autowired
	private AirlineService airlineService;
	
	@Autowired
	AirlineConverter airlineconverter;

	
	@PostMapping("/saveAirline")
	public ResponseEntity<AirlineDTO> saveAirline(@RequestBody @Valid AirlineDTO airlinedto)
	{
		final Airline airline=airlineconverter.covertToAirlineEntity(airlinedto);
		return new ResponseEntity<AirlineDTO>(airlineService.saveAirline(airline),HttpStatus.CREATED);
	}
	
	//build update airline REST API
		//localhost:8086/updateAirline/id
		@PutMapping("/updateAirline/{id}")
		public ResponseEntity<AirlineDTO> updateAirline(@Valid @PathVariable("id") int id,
			@RequestBody AirlineDTO airlineDTO )
		{
			final Airline airline =airlineconverter.covertToAirlineEntity(airlineDTO);
			return new ResponseEntity<AirlineDTO>(airlineService.updateAirline(id, airline),
					HttpStatus.OK);
		}
		
		
		//build GET airline REST API
		@GetMapping("/getAirlineById/{id}")
		public AirlineDTO getAirlineById(@PathVariable int id)
		{
			return airlineService.getAirlineById(id);
		}
		
		
		//build GET ALL airline REST API
				@GetMapping("/getAllAirline")
				public List<AirlineDTO> getAllAirline()
				{
					return airlineService.getAllAirline();
				}
				
				
		 //build delete passenger REST API
		@DeleteMapping("/deleteAirline/{id}")
			public String deleteAirline(@PathVariable int id)
			{
			return airlineService.deleteAirline(id);
			}
				
				 //build get by passenger name REST API
				@GetMapping("/getAirlineByName/{airlineName}")
				public List<AirlineDTO> getAirlineByName(@Valid @PathVariable("airlineName") String airlineName)
				{
					return airlineService.getAirlineByName(airlineName);
				}		
				

}
