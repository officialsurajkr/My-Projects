package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.airline.entity.Admin;
import com.airline.entity.Passenger;
import com.airline.service.AdminService;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AdminRepositoryTest 
{
	
		
	@Autowired
	private AdminRepository adminRepository;
	
	//this method is for testing saveAdmin Repository layer
	
//	@Test
//	@Rollback(value = false)
//	@Order(1)
//	@DisplayName("testing saveAdmin Repository method")
//	void saveAdminTest()
//	{
//		Admin admin=Admin.builder().aname("Suraj").aemail("sk@gmail.com").aphno("0212328976").
//				userName("admin").password("admin123").role("admin").build();
//		
//		Admin a=adminRepository.save(admin);
//	L.info("Admin"+admin.toString()+" added at "+ new java.util.Date());
//		assertThat(a.getAname()).isEqualTo("Suraj");
//
//	}
	
	//this method is for testing getAllAdmin Repository layer
	
	@Test
	@DisplayName("testing getAllAdmin repository method")
	@Rollback(value = false)
	@Order(3)
	void getAllAdminTest()
	{
		List<Admin> list=adminRepository.findAll();
		
		assertThat(list.size()).isGreaterThan(0);
	}
	
	//this method is for testing updateAdmin Repository layer
	@Test
	@DisplayName("testing updateAdmin repository method")
	@Rollback(value = false)
	@Order(2)
	void updateAdminTest()
	{
		Admin exAdmin=adminRepository.findById(8).get();
		exAdmin.setAname("Suraj Kumar");
		
		Admin a=adminRepository.save(exAdmin);
		
		assertThat(a.getAname()).isEqualTo("Suraj Kumar");
	}
	
	//this method is for testing deleteAdmin Repository layer
	@Test
	@DisplayName("testing deleteAdmin repository method")
	@Order(4)
	void deletePassenger()
	{
		adminRepository.deleteById(8);
		
		assertThrows(NoSuchElementException.class,()-> adminRepository.findById(7).get());
		
	}
	//this method is for testing negative case updateAdmin Repository layer
	@Test
	@DisplayName("negative test case")
	@Rollback(value = false)
	@Order(5)
	void updateAdminNegative()
	{
		Admin exAdmin=adminRepository.findById(8).get();
		exAdmin.setAname("sanjib");
		Admin a=adminRepository.save(exAdmin);
		
		assertThat(a.getAname()).isEqualTo("Suraj Kumar");
	}

	


}
