package com.ems.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.*;

import com.ems.entity.Address;
import com.ems.entity.Employee;

class EmployeeServiceTest {
	EmployeeService employeeservice;
	
	static List<Employee> emplist;
	
	@BeforeAll
	static void init()
	{
		emplist=new ArrayList<Employee>();
	}

	@BeforeEach
	void setUp() throws Exception {
		employeeservice=new EmployeeService();
		
	}

	@AfterEach
	void tearDown() throws Exception {
		 employeeservice = null;
		 System.out.println("object is garbage collected ");
	}

//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}
	
	@Test
	@DisplayName("testing add employee method")
	public void testAddEmployee()
	{
		//1st way
		employeeservice.addEmployee(101, "nil", 20000, "kolkata", "India");
		employeeservice.addEmployee(102, "suraj", 15000, "dhanbad", "India");
		//assertEquals(2,employeeservice.lengthOfList());  
						int length =employeeservice.lengthOfList();
						assertThat(length>0).isTrue();
					
						
		//2nd way with using builder
			Address add=Address.builder().city("kolkata").country("India").build();			
		Employee emp=Employee.builder().empId(101).empName("chandan").empSal(30000)
							.address(add).build();
		
		employeeservice.addEmp(emp);
		
		int length1 =employeeservice.lengthOfList();
				assertThat(length1>0).isTrue();
		
	}

}
