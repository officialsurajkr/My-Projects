package com.ems.exception;

public class GlobalException extends Exception
{
	public GlobalException(String message) 
	{
		super(message);
	}
}
