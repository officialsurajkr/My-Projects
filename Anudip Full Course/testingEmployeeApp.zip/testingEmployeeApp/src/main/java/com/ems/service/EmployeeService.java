package com.ems.service;

import java.util.ArrayList;
import java.util.List;
import com.ems.entity.Address;
import com.ems.entity.Employee;
import com.ems.exception.GlobalException;

public class EmployeeService 
{
	private List<Employee> employee=new ArrayList<Employee>();
	
	//method to add employee details in arraylist
	public void addEmployee(long empId, String name, double sal, String city, String country)
	{
		Address address=new Address(city,country);
		
		employee.add(new Employee(empId, name, sal, address));
	}
	
	
	//for testing using builder annotation
	
	public void addEmp(Employee emp)
	{
		employee.add(emp);
	}
	
	//method to display all employee details
	
	public void displayAllEmployee()
	{
		for(Employee emp: employee)
		{
			System.out.println("Employee Id:" +emp.getEmpId());
			System.out.println("Employee Name: "+emp.getEmpName());
			System.out.println("Employee Salary: "+emp.getEmpSal());
			System.out.println("Employee Address: "+emp.getAddress().getCity()+"  "+
			emp.getAddress().getCountry());
		}
	}
	
	//method to display all employee details by id
	
	public void displayEmpById(int id) throws GlobalException
	{
		for(int i=0; i<employee.size(); i++)
		{
			if(employee.get(i).getEmpId()==id)
			{
				System.out.println("Employee Id: "+employee.get(i).getEmpId());
				System.out.println("Employee Name: "+employee.get(i).getEmpName());
				System.out.println("Employee Salary: "+employee.get(i).getEmpSal());
				System.out.println("Employee Address: "+employee.get(i).getAddress().getCity()+" "+
				employee.get(i).getAddress().getCountry());
			}
			else
			{
				throw new GlobalException("Employee Id not found");
			}
		}//end of for block
	}
	
	//method to delete employee by id
	
	public void deleteEmpById(int id) throws GlobalException
	{
		for(int i=0; i<employee.size(); i++)
		{
			if(employee.get(i).getEmpId()==id)
			{
				employee.remove(i);			
			}
			else
			{
				throw new GlobalException("Employee Id not found");
			}
		}//end of for
	}
	
	//method for delete all employee
	
	public void deleteAllEmp()
	{	
		employee.clear();  //or
	//	employee.removeAll(employee);
		
	}
	
	
	//method for delete all employee
	
	public void updateEmpById(int id) throws GlobalException
	{
		for(int i=0; i<employee.size(); i++)
		{
			if(employee.get(i).getEmpId()== id)
			{
			
				//employee.set(i, new Employee(102, "suraj", 30000,));
	
			}
			else
			{
				throw new GlobalException("Employee Id not found");
			}
		}//end of for
	}
	
	//calculate the yearly salary of employee
	public double calculateYearlySalary(long id) throws GlobalException
	{
		double yearlysalary=0.0;
		
		for(int i=0; i<employee.size(); i++)
		{
			
			
			if(employee.get(i).getEmpId()== id)
			{
				 yearlysalary = employee.get(i).getEmpSal()*12;
			}
			else
			{
				throw new GlobalException("Employee Id not found");
			}
		}//end of for 
		return  yearlysalary ;
	}
	
	// calculate appraisal amount of employee
	
	public double calculateAppraisalById(long id) throws GlobalException
	{
		double appraisal=0.0;
		for(int i=0; i<employee.size(); i++)
		{
			
			if(employee.get(i).getEmpId()== id)
			{
				 if(employee.get(i).getEmpSal()<10000)
				 {
					 appraisal=1000;
				 }
				 else
				 {
					 appraisal=2000;
				 }
			}
			else
			{
				throw new GlobalException("Employee Id not found");
			}
		}//end of for 
		return  appraisal ;
		
	}
	
	//method length
	public int lengthOfList()
	{
		return	employee.size();
	}
}
