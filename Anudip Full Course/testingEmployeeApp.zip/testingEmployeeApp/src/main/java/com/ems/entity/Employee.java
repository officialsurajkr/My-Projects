package com.ems.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

//@Data //it will annotate getter(),setter(),toString(),equals(),hashCode() these all are included
////@Setter // if we require only setter()
////@Getter  //if we require only getter()
//@AllArgsConstructor  //it will annotate all parameterized constructor
//@NoArgsConstructor //it will annotate default constructor
//@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Employee
{
	private long empId;
	private String empName;
	private double empSal;
	
	//entity reference
	Address address;  //Has-A relationship / association

}
