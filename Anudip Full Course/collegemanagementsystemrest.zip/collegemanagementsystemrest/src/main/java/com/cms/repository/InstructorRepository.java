package com.cms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cms.entity.Instructor;
import com.cms.model.InstructorDTO;

public interface InstructorRepository extends JpaRepository<Instructor, Integer>{
	
	@Query("select i from Instructor i where i.firstName=?1")
List<Instructor> getInstructorByFirstName(String firstName);
	
@Query("select i from Instructor i where i.email=:email")	
Instructor	getInstructorByEmail(@Param("email") String email);

//for testing purpose
Optional<Instructor> findByFirstName(String name);
}
