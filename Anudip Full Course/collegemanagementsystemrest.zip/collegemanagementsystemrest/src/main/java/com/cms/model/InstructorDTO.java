package com.cms.model;


import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;



import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Component
public class InstructorDTO extends UserDTO{
	
	
	
	@NotNull
	@Size(min = 2,message = "first name should have minimum 2 characters")
	private String firstName;
	
	@NotNull
	@Size(min = 2,message = "last name should have minimum 2 characters")
	private String lastName;
	
	@Email
	@NotNull
	private String email;
	
}
