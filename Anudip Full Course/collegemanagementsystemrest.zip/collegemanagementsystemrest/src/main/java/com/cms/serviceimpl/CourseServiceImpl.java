package com.cms.serviceimpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.entity.Course;
import com.cms.entity.Instructor;
import com.cms.exception.ResourceNotFoundException;
import com.cms.model.CourseDTO;
import com.cms.repository.CourseRepository;
import com.cms.repository.InstructorRepository;
import com.cms.service.CourseService;
import com.cms.util.Converter;

@Service
public class CourseServiceImpl implements CourseService{

	@Autowired
	CourseRepository courseRepository;

	@Autowired
	InstructorRepository instructorRepository;
	
	@Autowired
	Converter converter;
	
	@Override
	public String deleteCourse(int id) {
		String message=null;
		Optional<Course>course = courseRepository.findById(id);
		if(course.isPresent())
		{
			courseRepository.deleteById(id);
			message=new String("Record deleted successfully");
			
		}
		else
		{
			//throw
		}
		
		return message;
	}


	@Override
	public String createCourse(Course course) {
		String message = null;
		courseRepository.save(course);
		if(course!= null)
		{
			message="Course saved succesfully";
		}
			return message;
	}

	@Override
	public CourseDTO updateCourse(int id, Course course) {
		//we need to check weather course with given id exists in Db or not
		Course existingCrs = courseRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Course", "Id", id));
		
		//we are getting data from client and set in existing course
		existingCrs.setId(course.getId());
		existingCrs.setTitle(course.getTitle());
		existingCrs.setPrice(course.getPrice());
		courseRepository.save(existingCrs);
		
		return converter.convertToCourseDTO(course);
	}

	@Override
	public CourseDTO getCourseById(int id) {
	Optional<Course>course = courseRepository.findById(id);
		
		Course crs = null;
		if (course.isPresent())
		{
			crs=course.get();
		}
		else
		{
			throw new ResourceNotFoundException("Course","Id",id);
		}
		return converter.convertToCourseDTO(crs);	
	}


	@Override
	public Course assignInstructor(int insId, int cId) {
	Instructor	ins1=instructorRepository.findById(insId).get();
	   Course c1 = courseRepository.findById(cId).get();
	   c1.setInstructor(ins1);	
	  return courseRepository.save(c1);
	    //return converter.convertToCourseDTO(c1);
	}

}
