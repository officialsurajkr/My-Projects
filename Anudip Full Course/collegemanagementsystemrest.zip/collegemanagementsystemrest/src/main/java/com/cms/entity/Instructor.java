package com.cms.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "instructors", uniqueConstraints = {
	@UniqueConstraint(columnNames = { "email"}) })
public class Instructor extends User {

	
	@Column(name = "fname",length = 50)
	private String firstName;
	
	@Column(name = "lname",length = 60)
	private String lastName;
	
	@Column(length = 150)         //@Column(length = 150,unique = true)
	private String email;
	
	@OneToMany(mappedBy = "instructor",cascade = CascadeType.ALL)
	@JsonIgnoreProperties("instructor") 
	private List<Course> course;

	@Builder
	public Instructor(Integer userId, String userName, String password, String firstName, String lastName, String email,
			List<Course> course) {
		super(userId, userName, password);
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.course = course;
	}
	
	
}
