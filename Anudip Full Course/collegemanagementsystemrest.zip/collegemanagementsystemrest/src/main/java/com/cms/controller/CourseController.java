package com.cms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cms.entity.Course;
import com.cms.model.CourseDTO;
import com.cms.service.CourseService;
import com.cms.util.Converter;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class CourseController {
	
	@Autowired
	CourseService courseService;
	
	@Autowired
	Converter converter;
	
	@PostMapping("/createCourse")
	public String createCourse (@Valid @RequestBody CourseDTO courseDTO)
	{
		final Course course = converter.covertToCourseEntity(courseDTO);
		return courseService.createCourse(course);
	}

	@DeleteMapping("/deleteCourse/{id}")
	public String deleteCourse(
	@PathVariable("id")	int cId)
	{
		return courseService.deleteCourse(cId);
	}
	
	//build update Instructor Rest Api
	
		@PutMapping("/updateCourse/{id}")
		public ResponseEntity<CourseDTO>updateCourse(@Valid @PathVariable ("id")int id,@RequestBody
				CourseDTO courseDTO)
		{
			final Course course = converter.covertToCourseEntity(courseDTO);
			return new ResponseEntity<CourseDTO>(courseService.updateCourse(id, course),
					HttpStatus.OK);
		}
		//build get course by id Rest api
		
		@GetMapping("/getCrsById/{id}")
		public CourseDTO getCourseById(@PathVariable("id")int id)
		{
			return courseService.getCourseById(id);
		}
		
		//assign course to instructor
		@PostMapping("/assignInstructor/{insId}/{cId}")
		public ResponseEntity<Course> assignInstructor(@PathVariable("insId") int insId,
				@PathVariable("cId") int cId)
		{
			return new ResponseEntity<Course>(courseService.assignInstructor(insId, cId),
					HttpStatus.CREATED);
		}
	
		
		
}
