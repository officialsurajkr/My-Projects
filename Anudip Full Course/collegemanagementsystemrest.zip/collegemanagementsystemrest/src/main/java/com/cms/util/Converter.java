package com.cms.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.cms.entity.Course;
import com.cms.entity.Instructor;
import com.cms.model.CourseDTO;
import com.cms.model.InstructorDTO;

@Component
public class Converter {

	//convert from DTO  to entity
	
	public Instructor covertToInstructorEntity(InstructorDTO instructorDTO)
	{
		Instructor instructor=new Instructor();
		if(instructorDTO!=null)
		{
			BeanUtils.copyProperties(instructorDTO, instructor);
		}
		return instructor;
	}
	
	
	//covert from Entity to DTO
	public InstructorDTO convertToInstructorDTO(Instructor instructor)
	{
		InstructorDTO instructorDTO=new InstructorDTO();
		if(instructor!=null)
		{
			BeanUtils.copyProperties(instructor, instructorDTO);
		}
		return instructorDTO;
	}
	
	
	//convert from DTO  to entity
	
		public Course covertToCourseEntity(CourseDTO courseDTO)
		{
			Course course=new Course();
			if(courseDTO!=null)
			{
				BeanUtils.copyProperties(courseDTO, course);
			}
			return course;
		}
		
		//covert from Entity to DTO
			public CourseDTO convertToCourseDTO(Course course)
			{
				CourseDTO courseDTO=new CourseDTO();
				if(course!=null)
				{
					BeanUtils.copyProperties(course, courseDTO);
				}
				return courseDTO;
			}
}
