package com.cms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cms.entity.Instructor;
import com.cms.model.InstructorDTO;
import com.cms.service.InstructorService;
import com.cms.util.Converter;


@RestController(value = "/api")
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class InstructorController {

	@Autowired
	InstructorService instructorService;
	
	@Autowired
	private Converter converter;
	
	//build create Instructor REST API
	@PostMapping("/createInstructor")
	public String createInstructor(@Valid @RequestBody InstructorDTO instructorDTO)
	{
	final Instructor instructor	=converter.covertToInstructorEntity(instructorDTO);
	return instructorService.createInstructor(instructor);
	}
	
	
	
	//build delete employee REST API
	//http://localhost:8085/api/employees/2	

//	@DeleteMapping("/api/deleteInsById/{id}")
//	public ResponseEntity<String> deleteInstructor(@PathVariable("id") long id)
//	{
//		
//	employeeService.deleteInstructor(id);
//	return new ResponseEntity<String>("Instructor deleted successfully", HttpStatus.OK);
//	}
//	
	
	//build delete Instructor REST API
	@DeleteMapping("/deleteInstructor/{id}")
	public String deleteInstructor(
	@PathVariable("id")	int insId)
	{
		return instructorService.deleteInstructor(insId);
	}
	

	
	//build update Instructor REST API
	//localhost:8086/api/updateInstructor/3
	@PutMapping("/updateInstructor/{id}")
	public ResponseEntity<InstructorDTO> updateInstructor(@Valid @PathVariable("id") int id,
			@RequestBody 
			InstructorDTO instructorDTO)
	
	{
		final Instructor instructor	=converter.covertToInstructorEntity(instructorDTO);
		return new ResponseEntity<InstructorDTO>(instructorService.updateInstructor(id, instructor),
				HttpStatus.OK);
	}
	
	//build get Instructor by id REST API
	//localhost:8086/api/getInsById/4
	@GetMapping("/getInsById/{id}")
	public InstructorDTO getInstructorById(@PathVariable("id") int id)
	{
		return instructorService.getInstructorById(id);
	}
	
	//build get All Instructor REST API
	//@GetMapping(value = "/getAllInstructors")
	//localhost:8086/api/getAllInstructors
	@GetMapping("/getAllInstructors")
	public List<InstructorDTO> getAllInstructors()
	{
		return instructorService.getAllInstructors();
	}
	
	
	//build get Instructor by firstname REST API
	//localhost:8086/api/getInsByFirstName/joydip
	@GetMapping("/getInsByFirstName/{fname}")
	public List<InstructorDTO> getInstructorByFirstName(@PathVariable("fname") String firstName)
	{
		return instructorService.getInstructorByFirstName(firstName);
	}
	
	//build get Instructor by email REST API
	//localhost:8086/api/getInsByEmail/priya@gmail.com
	  @GetMapping("/getInsByEmail/{email}")
	  public InstructorDTO  getInstructorByEmail(@PathVariable("email") String email)
	  {
		  return instructorService.getInstructorByEmail(email);
	  }
	  
	  
}






