package com.cms.service;

import java.util.List;

import com.cms.entity.Instructor;
import com.cms.model.InstructorDTO;

public interface InstructorService {
public String createInstructor(Instructor instructor);
public String deleteInstructor(int id);
public InstructorDTO updateInstructor(int id,Instructor instructor);
public InstructorDTO getInstructorById(int id);
public List<InstructorDTO> getAllInstructors();
public List<InstructorDTO> getInstructorByFirstName(String firstName);
public InstructorDTO getInstructorByEmail(String email);

}
