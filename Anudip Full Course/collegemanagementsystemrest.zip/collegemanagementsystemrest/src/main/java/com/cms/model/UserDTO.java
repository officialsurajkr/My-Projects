package com.cms.model;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class UserDTO {
	private int userId;
	
	@NotNull
	private String userName;

	@NotNull
	private String password;
}
