package com.cms.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.entity.Instructor;
import com.cms.exception.ResourceNotFoundException;
import com.cms.model.InstructorDTO;
import com.cms.repository.InstructorRepository;
import com.cms.service.InstructorService;
import com.cms.util.Converter;



@Service
public class InstructorServiceImpl implements InstructorService{

	private static final Logger l=LoggerFactory.getLogger(InstructorService.class);
	
	@Autowired
	private InstructorRepository instructorRepository;
	
	@Autowired
	private Converter converter;
	
	@Override
	public String createInstructor(Instructor instructor) {
		String message=null;
		instructor.setUserName(instructor.getUserName());
		instructor.setPassword(instructor.getPassword());
		instructorRepository.save(instructor);
		l.info("Inside servive Layer!!!!" + new java.util.Date());
		if(instructor!=null)
		{
		message="instructor saved successfully";
		}
		return message;
	}

//	public void deleteInstructor(long id) {
//		instructorRepository.findById(id).orElseThrow(()
//				->new ResourceNotFoundException("Instructor", "Id", id));
//		
//		instructorRepository.deleteById(id);
//			
//		}

	@Override
	public String deleteInstructor(int id) {
		String message=null;
	Optional<Instructor>instructor=instructorRepository.findById(id);
		if(instructor.isPresent()) {
			instructorRepository.deleteById(id);
			l.info("delete instructor by id: ", id);
			message=new String("Record deleted successfully");
		}
		else
		{
			//throw
			throw new ResourceNotFoundException("Instructor", "id", id);
		}
		return message;
	}

	

	@Override
	public InstructorDTO updateInstructor(int id, Instructor instructor) {

		//we need to check whether instructor with given id is exist in DB or not
	Instructor existingIns=instructorRepository.findById(id).orElseThrow(()->
	new ResourceNotFoundException("Instructor", "Id", id));
		
	//we are getting data from client and set in existing instructor
	existingIns.setFirstName(instructor.getFirstName());
	existingIns.setLastName(instructor.getLastName());
	existingIns.setEmail(instructor.getEmail());
	instructorRepository.save(existingIns);
	l.info("update instructor by id: ", id);
	return converter.convertToInstructorDTO(existingIns);
	}

	
	@Override
	public InstructorDTO getInstructorById(int id) {
		l.info("Get Instructor by id: ", id);
	Optional<Instructor> instructor=instructorRepository.findById(id);
	
	Instructor ins=null;
	if(instructor.isPresent())
	{
		ins=instructor.get();
	}
	else
	{
		throw new ResourceNotFoundException("Instructor", "Id", id);
	}
		return converter.convertToInstructorDTO(ins);
	}

	@Override
	public List<InstructorDTO> getAllInstructors() {
	 List<Instructor> instructors=instructorRepository.findAll();
	 l.info("Get All Instructor");
	 List<InstructorDTO> insDTO=new ArrayList<>();
	 for(Instructor instructor: instructors)
	 {
		 insDTO.add(converter.convertToInstructorDTO(instructor));
	 }
		return insDTO;
	}

	@Override
	public List<InstructorDTO> getInstructorByFirstName(String firstName) {
	
	List<Instructor> ins =instructorRepository.getInstructorByFirstName(firstName);
	l.info("Get Instructor by firstName: ", firstName);
	 List<InstructorDTO> DTO=new ArrayList<>();
	 for(Instructor instructor: ins)
	 {
		DTO.add(converter.convertToInstructorDTO(instructor));
	 }
		return DTO;
	}

	@Override
	public InstructorDTO getInstructorByEmail(String email) {
	Instructor	instructor=instructorRepository.getInstructorByEmail(email);
	l.info("Get Instructor by email: ", email);
		return converter.convertToInstructorDTO(instructor);
	}
}
