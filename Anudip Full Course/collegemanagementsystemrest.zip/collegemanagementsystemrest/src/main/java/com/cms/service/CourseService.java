package com.cms.service;

import com.cms.entity.Course;
import com.cms.model.CourseDTO;

public interface CourseService {
	public String createCourse(Course course);
	public String deleteCourse(int id);
	public CourseDTO updateCourse(int id,Course course);
	public CourseDTO getCourseById (int id);
	Course assignInstructor(int insId,int cId);
}
