package com.cms.service;

import com.cms.entity.User;

public interface UserService {
public User login(String userName,String password);
}
