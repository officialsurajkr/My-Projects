package com.cms.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.filter.GenericFilterBean;

import com.cms.entity.Instructor;
import com.cms.entity.User;
import com.cms.service.InstructorService;
import com.cms.service.UserService;
import com.cms.util.Converter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;

@WebMvcTest(InstructorController.class)
class InstructorControllerTest{

	@Autowired
	private MockMvc mockMvc;
	
	Instructor instructor;
	
	@MockBean
	InstructorService instructorService;
	@MockBean
	Converter converter;
	
	@MockBean
	UserService userService;
	
	String jwtToken="";
	@BeforeEach
	void setUp()
	{
		instructor=new Instructor();
		instructor.setFirstName("ram");
		instructor.setLastName("sharma");
		instructor.setEmail("ram@gmail.com");
		instructor.setUserName("admin");
		instructor.setPassword("admin123");
	}

	
	
	String tokenCreation() throws ServletException
	{
		if (instructor.getUserName() == null || instructor.getPassword() == null) {
			throw new ServletException("Please fill in username and password");
		}

		String userName = instructor.getUserName();
		String password = instructor.getPassword();
		//Mockito.when(userService.login(userName, password)).thenReturn(instructor);
	

		//String userName="ram";
		jwtToken = Jwts.builder().setSubject(userName).claim("roles", "user").setIssuedAt(new Date())
				.signWith(SignatureAlgorithm.HS256, "secretkey").compact();

		return jwtToken;
	}
	
	@Test
	void testSaveInstructor() throws Exception
	{
		String accessToken=tokenCreation();
		System.out.println("access token: "+accessToken);
		
		mockMvc.perform(MockMvcRequestBuilders.post("/api/createInstructor").contentType(MediaType.APPLICATION_JSON)
				.content("{\r\n" + "  \"userId\": 101,\r\n" + "  \"firstName\": \"ram\",\r\n" + "  \"lastName\": dutta,\r\n"
						+ "  \"email\": \"ram@gmail.com\"\r\n" +"  \"userName\": \"ram\",\r\n"+ 
						"  \"password\": \"ram123\",\r\n"+"}").header(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken))
				.andExpect(MockMvcResultMatchers.status().isBadRequest());	
	}

	

}
